package com.flowos.infinix.core.launcher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import com.flowos.infinix.MainActivity
import com.flowos.infinix.R

/**
 * Optional floating edge pill that lets the user jump smoothly into FlowOS's
 * Quick App Switcher from any app, avoiding laggy XOS Recents.
 */
class QuickSwitcherOverlayService : Service() {

    companion object {
        const val ACTION_OPEN_SWITCHER = "com.flowos.infinix.OPEN_SWITCHER"
        private const val CHANNEL_ID = "flowos_quick_switcher"
        private const val NOTIF_ID = 7001

        fun start(context: Context) {
            if (!Settings.canDrawOverlays(context)) return
            val intent = Intent(context, QuickSwitcherOverlayService::class.java)
            context.startForegroundService(intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, QuickSwitcherOverlayService::class.java))
        }
    }

    private var windowManager: WindowManager? = null
    private var handleView: View? = null

    override fun onCreate() {
        super.onCreate()
        startForegroundWithNotification()
        if (Settings.canDrawOverlays(this)) {
            attachEdgeHandle()
        } else {
            stopSelf()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        handleView?.let { runCatching { windowManager?.removeView(it) } }
        handleView = null
        super.onDestroy()
    }

    private fun startForegroundWithNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.overlay_channel_name),
            NotificationManager.IMPORTANCE_MIN
        )
        nm.createNotificationChannel(channel)

        val openIntent = Intent(this, MainActivity::class.java).apply {
            action = ACTION_OPEN_SWITCHER
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        val pi = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.overlay_notification_title))
            .setContentText(getString(R.string.overlay_notification_text))
            .setSmallIcon(android.R.drawable.ic_menu_sort_by_size)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()

        startForeground(NOTIF_ID, notification)
    }

    private fun attachEdgeHandle() {
        windowManager = getSystemService(WindowManager::class.java)
        val density = resources.displayMetrics.density

        val pill = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 12f * density
                setColor(0x9938BDF8.toInt())
                setStroke((1 * density).toInt(), 0x80FFFFFF.toInt())
            }
        }

        val params = WindowManager.LayoutParams(
            (7 * density).toInt(),
            (84 * density).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            y = 0
        }

        var initialY = 0
        var initialTouchY = 0f
        var moved = false

        pill.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialY = params.y
                    initialTouchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (kotlin.math.abs(dy) > 10) {
                        moved = true
                        params.y = initialY + dy
                        runCatching { windowManager?.updateViewLayout(pill, params) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        val openIntent = Intent(this, MainActivity::class.java).apply {
                            action = ACTION_OPEN_SWITCHER
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        }
                        startActivity(openIntent)
                    }
                    true
                }
                else -> false
            }
        }

        runCatching {
            windowManager?.addView(pill, params)
            handleView = pill
        }
    }
}
