package com.flowos.infinix.core.theme

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.flowos.infinix.core.prefs.AppThemeMode

/**
 * 120Hz iOS-inspired spring physics tuned for Infinix Hot 50 LCD.
 */
object FlowSprings {
    fun <T> appLaunch(speedMultiplier: Float = 1.0f) = spring<T>(
        dampingRatio = 0.84f,
        stiffness = 380f * speedMultiplier
    )

    val folderExpand = spring<Float>(
        dampingRatio = 0.82f,
        stiffness = 420f
    )

    val dockBounce = spring<Float>(
        dampingRatio = 0.65f,
        stiffness = 500f
    )

    val sheetOffset = spring<IntOffset>(
        dampingRatio = Spring.DampingRatioNoBouncy,
        stiffness = Spring.StiffnessMediumLow
    )
}

data class FlowGlassPalette(
    val glassSurface: Color,
    val glassSurfaceElevated: Color,
    val glassBorder: Color,
    val dockSurface: Color,
    val accentBlue: Color,
    val accentCyan: Color,
    val successGreen: Color,
    val warningAmber: Color,
    val dangerRed: Color,
    val subtleText: Color
)

private val DarkGlassPalette = FlowGlassPalette(
    glassSurface = Color(0xCC161B26),
    glassSurfaceElevated = Color(0xE61E2636),
    glassBorder = Color(0x33FFFFFF),
    dockSurface = Color(0x991C2230),
    accentBlue = Color(0xFF38BDF8),
    accentCyan = Color(0xFF22D3EE),
    successGreen = Color(0xFF34D399),
    warningAmber = Color(0xFFFBBF24),
    dangerRed = Color(0xFFF87171),
    subtleText = Color(0xFFB6C2D9)
)

private val LightGlassPalette = FlowGlassPalette(
    glassSurface = Color(0xD9F8FAFC),
    glassSurfaceElevated = Color(0xF0FFFFFF),
    glassBorder = Color(0x330F172A),
    dockSurface = Color(0xB8F1F5F9),
    accentBlue = Color(0xFF0284C7),
    accentCyan = Color(0xFF0EA5E9),
    successGreen = Color(0xFF059669),
    warningAmber = Color(0xFFD97706),
    dangerRed = Color(0xFFDC2626),
    subtleText = Color(0xFF475569)
)

val LocalGlassPalette = staticCompositionLocalOf { DarkGlassPalette }

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF38BDF8),
    onPrimary = Color(0xFF041E2B),
    secondary = Color(0xFF818CF8),
    background = Color(0xFF090D16),
    surface = Color(0xFF131926),
    surfaceVariant = Color(0xFF1E2638),
    onBackground = Color(0xFFF8FAFC),
    onSurface = Color(0xFFF8FAFC),
    onSurfaceVariant = Color(0xFFB6C2D9),
    error = Color(0xFFF87171)
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF0284C7),
    onPrimary = Color.White,
    secondary = Color(0xFF4F46E5),
    background = Color(0xFFF1F5F9),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFE2E8F0),
    onBackground = Color(0xFF0F172A),
    onSurface = Color(0xFF0F172A),
    onSurfaceVariant = Color(0xFF475569),
    error = Color(0xFFDC2626)
)

private val FlowTypography = Typography(
    headlineLarge = TextStyle(fontSize = 26.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.3).sp),
    headlineSmall = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
    bodyMedium = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Normal, lineHeight = 20.sp),
    labelMedium = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Medium),
    labelSmall = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Medium)
)

object FlowDimens {
    val CardRadius = 22.dp
    val DockRadius = 30.dp
    val IconRadius = 16.dp
}

@Composable
fun FlowOSTheme(
    themeMode: AppThemeMode,
    content: @Composable () -> Unit
) {
    val isDark = when (themeMode) {
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
        AppThemeMode.DARK -> true
        AppThemeMode.LIGHT -> false
    }

    val colorScheme = if (isDark) DarkColorScheme else LightColorScheme
    val glassPalette = if (isDark) DarkGlassPalette else LightGlassPalette

    CompositionLocalProvider(LocalGlassPalette provides glassPalette) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = FlowTypography,
            content = content
        )
    }
}
