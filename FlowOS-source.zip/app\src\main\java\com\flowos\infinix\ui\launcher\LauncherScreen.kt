package com.flowos.infinix.ui.launcher

import android.graphics.Rect
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.HealthAndSafety
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.ViewCarousel
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.flowos.infinix.core.apps.AppCategory
import com.flowos.infinix.core.apps.AppEntry
import com.flowos.infinix.core.i18n.LocalStrings
import com.flowos.infinix.core.theme.FlowDimens
import com.flowos.infinix.core.theme.FlowSprings
import com.flowos.infinix.core.theme.LocalGlassPalette
import com.flowos.infinix.ui.components.GlassCard
import com.flowos.infinix.ui.components.formatBytes
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@Composable
fun LauncherScreen(
    apps: List<AppEntry>,
    recentApps: List<AppEntry>,
    dockPackages: Set<String>,
    showAppLabels: Boolean,
    animationMultiplier: Float,
    availableRamMb: Long,
    totalRamMb: Long,
    freeStorageBytes: Long,
    showQuickSwitcher: Boolean,
    onToggleQuickSwitcher: (Boolean) -> Unit,
    getIcon: (String) -> ImageBitmap?,
    onLaunchApp: (AppEntry, android.view.View, Rect?) -> Unit,
    onToggleDockPin: (String) -> Unit,
    onOpenAppInfo: (String) -> Unit,
    onUninstallApp: (String) -> Unit,
    onNavigateSystemFix: () -> Unit,
    onNavigateStorage: () -> Unit,
    onNavigateSettings: () -> Unit
) {
    val s = LocalStrings.current
    val palette = LocalGlassPalette.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()

    var searchQuery by remember { mutableStateOf("") }
    var expandedCategory by remember { mutableStateOf<AppCategory?>(null) }
    var launchingApp by remember { mutableStateOf<AppEntry?>(null) }

    // Determine Dock apps (user pinned or smart defaults)
    val dockApps = remember(apps, dockPackages) {
        if (dockPackages.isNotEmpty()) {
            apps.filter { dockPackages.contains(it.packageName) }.take(4)
        } else {
            apps.filter { !it.isSystemApp }.take(4)
        }
    }

    // Home grid apps exclude Dock apps so screen stays clean like iOS
    val dockSet = remember(dockApps) { dockApps.map { it.packageName }.toSet() }
    val homeApps = remember(apps, dockSet) {
        apps.filterNot { dockSet.contains(it.packageName) }
    }

    val homePages = remember(homeApps) {
        if (homeApps.isEmpty()) listOf(emptyList())
        else homeApps.chunked(16)
    }
    // Last page is always iOS App Library
    val totalPages = homePages.size + 1
    val pagerState = rememberPagerState(initialPage = 0, pageCount = { totalPages })

    val triggerLaunch: (AppEntry, Rect?) -> Unit = { entry, rect ->
        scope.launch {
            launchingApp = entry
            delay(110)
            onLaunchApp(entry, view, rect)
            delay(250)
            launchingApp = null
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color.Black.copy(alpha = 0.20f),
                        Color.Black.copy(alpha = 0.35f)
                    )
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top FlowOS Quick Pill Bar (Health + Storage + Switcher + Settings)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TopActionChip(
                        icon = Icons.Rounded.HealthAndSafety,
                        label = "${availableRamMb}MB",
                        tint = palette.successGreen,
                        onClick = onNavigateSystemFix
                    )
                    TopActionChip(
                        icon = Icons.Rounded.Storage,
                        label = formatBytes(freeStorageBytes),
                        tint = palette.accentBlue,
                        onClick = onNavigateStorage
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TopActionChip(
                        icon = Icons.Rounded.ViewCarousel,
                        label = s.quickSwitcherTitle,
                        tint = palette.accentCyan,
                        onClick = { onToggleQuickSwitcher(true) }
                    )
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(palette.glassSurface)
                            .border(1.dp, palette.glassBorder, CircleShape)
                            .clickable(onClick = onNavigateSettings),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Rounded.Settings,
                            contentDescription = s.settingsTab,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Paged Home Screen + App Library
            HorizontalPager(
                state = pagerState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) { pageIndex ->
                if (pageIndex < homePages.size) {
                    val pageItems = homePages[pageIndex]
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp)
                    ) {
                        if (pageIndex == 0) {
                            FlowHeroWidget(
                                availableRamMb = availableRamMb,
                                totalRamMb = totalRamMb,
                                freeStorageBytes = freeStorageBytes,
                                onFixSystemClick = onNavigateSystemFix,
                                onStorageClick = onNavigateStorage
                            )
                            Spacer(Modifier.height(12.dp))
                        }

                        LazyVerticalGrid(
                            columns = GridCells.Fixed(4),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            contentPadding = PaddingValues(vertical = 8.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(pageItems, key = { it.packageName }) { app ->
                                SpringAppIconItem(
                                    entry = app,
                                    icon = getIcon(app.packageName),
                                    showLabel = showAppLabels,
                                    isPinnedToDock = dockSet.contains(app.packageName),
                                    speedMultiplier = animationMultiplier,
                                    onLaunch = { rect -> triggerLaunch(app, rect) },
                                    onToggleDock = { onToggleDockPin(app.packageName) },
                                    onAppInfo = { onOpenAppInfo(app.packageName) },
                                    onUninstall = { onUninstallApp(app.packageName) }
                                )
                            }
                        }
                    }
                } else {
                    // iOS App Library Page
                    AppLibraryPage(
                        apps = apps,
                        searchQuery = searchQuery,
                        onSearchQueryChange = { searchQuery = it },
                        getIcon = getIcon,
                        showLabels = showAppLabels,
                        dockSet = dockSet,
                        speedMultiplier = animationMultiplier,
                        onCategoryOpen = { expandedCategory = it },
                        onLaunchApp = triggerLaunch,
                        onToggleDock = onToggleDockPin,
                        onOpenAppInfo = onOpenAppInfo,
                        onUninstallApp = onUninstallApp
                    )
                }
            }

            // Page indicator dots
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(totalPages) { idx ->
                    val selected = pagerState.currentPage == idx
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 4.dp)
                            .size(if (selected) 8.dp else 6.dp)
                            .clip(CircleShape)
                            .background(
                                if (selected) Color.White else Color.White.copy(alpha = 0.4f)
                            )
                    )
                }
            }

            // iOS Frosted Glass Dock
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .clip(RoundedCornerShape(FlowDimens.DockRadius))
                    .background(palette.dockSurface)
                    .border(1.dp, palette.glassBorder, RoundedCornerShape(FlowDimens.DockRadius))
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    dockApps.forEach { app ->
                        SpringAppIconItem(
                            entry = app,
                            icon = getIcon(app.packageName),
                            showLabel = false,
                            isPinnedToDock = true,
                            speedMultiplier = animationMultiplier,
                            onLaunch = { rect -> triggerLaunch(app, rect) },
                            onToggleDock = { onToggleDockPin(app.packageName) },
                            onAppInfo = { onOpenAppInfo(app.packageName) },
                            onUninstall = { onUninstallApp(app.packageName) }
                        )
                    }

                    // FlowOS Library Quick Jump in Dock
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .clickable {
                                scope.launch {
                                    pagerState.animateScrollToPage(totalPages - 1)
                                }
                            }
                            .padding(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(RoundedCornerShape(FlowDimens.IconRadius))
                                .background(
                                    Brush.linearGradient(
                                        listOf(palette.accentBlue, palette.accentCyan)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Rounded.Apps,
                                contentDescription = s.libraryTab,
                                tint = Color.White,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                }
            }
        }

        // Expanded Folder / Category Overlay with Spring Scale Animation
        AnimatedVisibility(
            visible = expandedCategory != null,
            enter = fadeIn() + scaleIn(
                initialScale = 0.85f,
                animationSpec = FlowSprings.appLaunch(animationMultiplier)
            ),
            exit = fadeOut() + scaleOut(targetScale = 0.88f)
        ) {
            val cat = expandedCategory
            if (cat != null) {
                val catApps = apps.filter { it.category == cat }
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.6f))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { expandedCategory = null }
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    GlassCard(
                        elevated = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) { /* consume */ }
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = categoryTitle(cat, s),
                                style = MaterialTheme.typography.headlineSmall
                            )
                            IconButton(onClick = { expandedCategory = null }) {
                                Icon(Icons.Rounded.Close, contentDescription = s.close)
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(4),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                            modifier = Modifier.height(340.dp)
                        ) {
                            items(catApps, key = { it.packageName }) { app ->
                                SpringAppIconItem(
                                    entry = app,
                                    icon = getIcon(app.packageName),
                                    showLabel = true,
                                    isPinnedToDock = dockSet.contains(app.packageName),
                                    speedMultiplier = animationMultiplier,
                                    onLaunch = { rect ->
                                        expandedCategory = null
                                        triggerLaunch(app, rect)
                                    },
                                    onToggleDock = { onToggleDockPin(app.packageName) },
                                    onAppInfo = { onOpenAppInfo(app.packageName) },
                                    onUninstall = { onUninstallApp(app.packageName) }
                                )
                            }
                        }
                    }
                }
            }
        }

        // iOS-Style Quick App Switcher Deck
        AnimatedVisibility(
            visible = showQuickSwitcher,
            enter = fadeIn() + scaleIn(
                initialScale = 0.92f,
                animationSpec = FlowSprings.appLaunch(animationMultiplier)
            ),
            exit = fadeOut() + scaleOut(targetScale = 0.94f)
        ) {
            QuickAppSwitcherOverlay(
                recentApps = recentApps,
                getIcon = getIcon,
                onSelectApp = { app, rect ->
                    onToggleQuickSwitcher(false)
                    triggerLaunch(app, rect)
                },
                onDismiss = { onToggleQuickSwitcher(false) }
            )
        }

        // Smooth Spring Launch Visual Splash Overlay
        AnimatedVisibility(
            visible = launchingApp != null,
            enter = fadeIn() + scaleIn(
                initialScale = 0.55f,
                animationSpec = FlowSprings.appLaunch(animationMultiplier)
            ),
            exit = fadeOut()
        ) {
            val app = launchingApp
            if (app != null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(palette.glassSurfaceElevated),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        val bmp = getIcon(app.packageName)
                        if (bmp != null) {
                            Image(
                                bitmap = bmp,
                                contentDescription = app.label,
                                modifier = Modifier
                                    .size(88.dp)
                                    .clip(RoundedCornerShape(22.dp))
                            )
                        }
                        Spacer(Modifier.height(14.dp))
                        Text(
                            text = app.label,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TopActionChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit
) {
    val palette = LocalGlassPalette.current
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(palette.glassSurface)
            .border(1.dp, palette.glassBorder, RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(6.dp))
        Text(
            text = label,
            color = Color.White,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
private fun FlowHeroWidget(
    availableRamMb: Long,
    totalRamMb: Long,
    freeStorageBytes: Long,
    onFixSystemClick: () -> Unit,
    onStorageClick: () -> Unit
) {
    val s = LocalStrings.current
    val palette = LocalGlassPalette.current

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(palette.successGreen.copy(alpha = 0.14f))
                    .clickable(onClick = onFixSystemClick)
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Rounded.HealthAndSafety,
                        contentDescription = null,
                        tint = palette.successGreen,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = s.fixerTab,
                        style = MaterialTheme.typography.labelMedium,
                        color = palette.successGreen,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "${availableRamMb}MB / ${totalRamMb}MB",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(palette.accentBlue.copy(alpha = 0.14f))
                    .clickable(onClick = onStorageClick)
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Rounded.CleaningServices,
                        contentDescription = null,
                        tint = palette.accentBlue,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = s.storageTab,
                        style = MaterialTheme.typography.labelMedium,
                        color = palette.accentBlue,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "${formatBytes(freeStorageBytes)} ${s.catFree}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SpringAppIconItem(
    entry: AppEntry,
    icon: ImageBitmap?,
    showLabel: Boolean,
    isPinnedToDock: Boolean,
    speedMultiplier: Float,
    onLaunch: (Rect?) -> Unit,
    onToggleDock: () -> Unit,
    onAppInfo: () -> Unit,
    onUninstall: () -> Unit
) {
    val s = LocalStrings.current
    val scope = rememberCoroutineScope()
    val scale = remember { Animatable(1f) }
    var boundsRect by remember { mutableStateOf<Rect?>(null) }
    var menuOpen by remember { mutableStateOf(false) }

    Box(contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .graphicsLayer {
                    scaleX = scale.value
                    scaleY = scale.value
                }
                .onGloballyPositioned { coords ->
                    val b = coords.boundsInWindow()
                    boundsRect = Rect(
                        b.left.roundToInt(),
                        b.top.roundToInt(),
                        b.right.roundToInt(),
                        b.bottom.roundToInt()
                    )
                }
                .clip(RoundedCornerShape(16.dp))
                .combinedClickable(
                    onClick = {
                        scope.launch {
                            scale.animateTo(0.88f, FlowSprings.dockBounce)
                            scale.animateTo(1.06f, FlowSprings.appLaunch(speedMultiplier))
                            onLaunch(boundsRect)
                            scale.animateTo(1f, FlowSprings.appLaunch(speedMultiplier))
                        }
                    },
                    onLongClick = { menuOpen = true }
                )
                .padding(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(FlowDimens.IconRadius))
                    .background(Color.White.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                if (icon != null) {
                    Image(
                        bitmap = icon,
                        contentDescription = entry.label,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Text(
                        text = entry.label.take(1).uppercase(),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp
                    )
                }
            }
            if (showLabel) {
                Spacer(Modifier.height(5.dp))
                Text(
                    text = entry.label,
                    color = Color.White,
                    style = MaterialTheme.typography.labelSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center
                )
            }
        }

        DropdownMenu(
            expanded = menuOpen,
            onDismissRequest = { menuOpen = false }
        ) {
            DropdownMenuItem(
                text = { Text(if (isPinnedToDock) s.unpinFromDock else s.pinToDock) },
                leadingIcon = { Icon(Icons.Rounded.PushPin, contentDescription = null) },
                onClick = {
                    menuOpen = false
                    onToggleDock()
                }
            )
            DropdownMenuItem(
                text = { Text(s.appInfo) },
                leadingIcon = { Icon(Icons.Rounded.Info, contentDescription = null) },
                onClick = {
                    menuOpen = false
                    onAppInfo()
                }
            )
            if (!entry.isSystemApp) {
                DropdownMenuItem(
                    text = { Text(s.uninstallApp) },
                    leadingIcon = { Icon(Icons.Rounded.Delete, contentDescription = null) },
                    onClick = {
                        menuOpen = false
                        onUninstall()
                    }
                )
            }
        }
    }
}

@Composable
private fun AppLibraryPage(
    apps: List<AppEntry>,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    getIcon: (String) -> ImageBitmap?,
    showLabels: Boolean,
    dockSet: Set<String>,
    speedMultiplier: Float,
    onCategoryOpen: (AppCategory) -> Unit,
    onLaunchApp: (AppEntry, Rect?) -> Unit,
    onToggleDock: (String) -> Unit,
    onOpenAppInfo: (String) -> Unit,
    onUninstallApp: (String) -> Unit
) {
    val s = LocalStrings.current
    val palette = LocalGlassPalette.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Text(
            text = "${s.appLibraryTitle} (${apps.size} ${s.allAppsCount})",
            color = Color.White,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(10.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchQueryChange,
            placeholder = { Text(s.searchAppsHint, color = Color.White.copy(alpha = 0.65f)) },
            leadingIcon = {
                Icon(Icons.Rounded.Search, contentDescription = null, tint = Color.White)
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchQueryChange("") }) {
                        Icon(Icons.Rounded.Close, contentDescription = s.close, tint = Color.White)
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(18.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = palette.glassSurface,
                unfocusedContainerColor = palette.glassSurface,
                focusedBorderColor = palette.accentBlue,
                unfocusedBorderColor = palette.glassBorder,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(14.dp))

        if (searchQuery.isNotBlank()) {
            val filtered = remember(apps, searchQuery) {
                val q = searchQuery.trim().lowercase()
                apps.filter {
                    it.label.lowercase().contains(q) || it.packageName.lowercase().contains(q)
                }
            }
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filtered, key = { it.packageName }) { app ->
                    SpringAppIconItem(
                        entry = app,
                        icon = getIcon(app.packageName),
                        showLabel = showLabels,
                        isPinnedToDock = dockSet.contains(app.packageName),
                        speedMultiplier = speedMultiplier,
                        onLaunch = { rect -> onLaunchApp(app, rect) },
                        onToggleDock = { onToggleDock(app.packageName) },
                        onAppInfo = { onOpenAppInfo(app.packageName) },
                        onUninstall = { onUninstallApp(app.packageName) }
                    )
                }
            }
        } else {
            val grouped = remember(apps) {
                AppCategory.entries.mapNotNull { cat ->
                    val list = apps.filter { it.category == cat }
                    if (list.isEmpty()) null else cat to list
                }
            }
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(grouped, key = { it.first.name }) { (category, catApps) ->
                    GlassCard(
                        onClick = { onCategoryOpen(category) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = categoryTitle(category, s),
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(10.dp))
                        val preview = catApps.take(4)
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            preview.forEach { app ->
                                val bmp = getIcon(app.packageName)
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Color.White.copy(alpha = 0.1f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (bmp != null) {
                                        Image(
                                            bitmap = bmp,
                                            contentDescription = app.label,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = "${catApps.size} ${s.allAppsCount}",
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.subtleText
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun QuickAppSwitcherOverlay(
    recentApps: List<AppEntry>,
    getIcon: (String) -> ImageBitmap?,
    onSelectApp: (AppEntry, Rect?) -> Unit,
    onDismiss: () -> Unit
) {
    val s = LocalStrings.current
    val palette = LocalGlassPalette.current
    val listState = rememberLazyListState()
    val snapBehavior = rememberSnapFlingBehavior(lazyListState = listState)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.72f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onDismiss
            )
            .padding(vertical = 40.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
            ) {
                Text(
                    text = s.quickSwitcherTitle,
                    color = Color.White,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Rounded.Close, contentDescription = s.close, tint = Color.White)
                }
            }
            Spacer(Modifier.height(16.dp))

            if (recentApps.isEmpty()) {
                GlassCard(modifier = Modifier.padding(horizontal = 24.dp)) {
                    Text(s.recentAppsEmpty, style = MaterialTheme.typography.bodyMedium)
                }
            } else {
                LazyRow(
                    state = listState,
                    flingBehavior = snapBehavior,
                    contentPadding = PaddingValues(horizontal = 36.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(recentApps, key = { it.packageName }) { app ->
                        var cardRect by remember { mutableStateOf<Rect?>(null) }
                        GlassCard(
                            elevated = true,
                            onClick = { onSelectApp(app, cardRect) },
                            modifier = Modifier
                                .width(220.dp)
                                .height(300.dp)
                                .onGloballyPositioned { coords ->
                                    val b = coords.boundsInWindow()
                                    cardRect = Rect(
                                        b.left.roundToInt(),
                                        b.top.roundToInt(),
                                        b.right.roundToInt(),
                                        b.bottom.roundToInt()
                                    )
                                }
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier.fillMaxSize()
                            ) {
                                val bmp = getIcon(app.packageName)
                                Box(
                                    modifier = Modifier
                                        .size(84.dp)
                                        .clip(RoundedCornerShape(22.dp))
                                        .background(palette.accentBlue.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (bmp != null) {
                                        Image(
                                            bitmap = bmp,
                                            contentDescription = app.label,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    }
                                }
                                Spacer(Modifier.height(18.dp))
                                Text(
                                    text = app.label,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = app.packageName,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = palette.subtleText,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun categoryTitle(category: AppCategory, s: com.flowos.infinix.core.i18n.FlowStrings): String {
    return when (category) {
        AppCategory.SOCIAL -> s.catSocial
        AppCategory.MEDIA -> s.catMedia
        AppCategory.GAMES -> s.catGames
        AppCategory.PRODUCTIVITY -> s.catProductivity
        AppCategory.TOOLS -> s.catTools
        AppCategory.SYSTEM -> s.catSystem
    }
}
