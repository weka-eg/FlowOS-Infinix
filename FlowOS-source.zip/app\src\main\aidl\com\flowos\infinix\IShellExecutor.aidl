package com.flowos.infinix;

interface IShellExecutor {
    String exec(String command);
    void destroy();
}
