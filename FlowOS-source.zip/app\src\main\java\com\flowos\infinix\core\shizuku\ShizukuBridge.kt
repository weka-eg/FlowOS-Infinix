package com.flowos.infinix.core.shizuku

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import android.provider.Settings
import com.flowos.infinix.BuildConfig
import com.flowos.infinix.IShellExecutor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import rikka.shizuku.Shizuku
import kotlin.coroutines.resume

enum class ShizukuStatus {
    NOT_INSTALLED,
    NOT_RUNNING,
    PERMISSION_REQUIRED,
    READY
}

data class ShellResult(
    val success: Boolean,
    val output: String
)

class ShizukuBridge(private val context: Context) {

    companion object {
        private const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
        private const val PERMISSION_REQUEST_CODE = 5001
    }

    private val _status = MutableStateFlow(ShizukuStatus.NOT_RUNNING)
    val status: StateFlow<ShizukuStatus> = _status.asStateFlow()

    @Volatile
    private var shellService: IShellExecutor? = null
    private var bindingInProgress = false

    private val userServiceArgs by lazy {
        Shizuku.UserServiceArgs(
            ComponentName(context.packageName, ShellUserService::class.java.name)
        )
            .daemon(false)
            .processNameSuffix("shell")
            .debuggable(BuildConfig.DEBUG)
            .version(BuildConfig.VERSION_CODE)
    }

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            shellService = IShellExecutor.Stub.asInterface(service)
            bindingInProgress = false
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            shellService = null
            bindingInProgress = false
        }
    }

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        refreshStatus()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        shellService = null
        refreshStatus()
    }

    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == PERMISSION_REQUEST_CODE) {
                refreshStatus()
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    ensureBound()
                }
            }
        }

    fun registerListeners() {
        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        Shizuku.addRequestPermissionResultListener(permissionResultListener)
        refreshStatus()
    }

    fun unregisterListeners() {
        runCatching { Shizuku.removeBinderReceivedListener(binderReceivedListener) }
        runCatching { Shizuku.removeBinderDeadListener(binderDeadListener) }
        runCatching { Shizuku.removeRequestPermissionResultListener(permissionResultListener) }
        runCatching {
            if (shellService != null) {
                Shizuku.unbindUserService(userServiceArgs, serviceConnection, true)
            }
        }
    }

    fun refreshStatus(): ShizukuStatus {
        val installed = isShizukuInstalled()
        val next = when {
            !installed -> ShizukuStatus.NOT_INSTALLED
            !Shizuku.pingBinder() -> ShizukuStatus.NOT_RUNNING
            Shizuku.isPreV11() -> ShizukuStatus.NOT_RUNNING
            Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED ->
                ShizukuStatus.PERMISSION_REQUIRED
            else -> ShizukuStatus.READY
        }
        _status.value = next
        if (next == ShizukuStatus.READY && shellService == null) {
            ensureBound()
        }
        return next
    }

    fun isShizukuInstalled(): Boolean {
        return try {
            context.packageManager.getPackageInfo(SHIZUKU_PACKAGE, 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }
    }

    fun requestPermission() {
        if (Shizuku.pingBinder() && !Shizuku.isPreV11()) {
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                Shizuku.requestPermission(PERMISSION_REQUEST_CODE)
            } else {
                refreshStatus()
            }
        }
    }

    fun openShizukuApp() {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
        }
    }

    fun openDeveloperOptions() {
        val intent = Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { context.startActivity(intent) }
    }

    private fun ensureBound() {
        if (shellService != null || bindingInProgress) return
        if (refreshStatusFast() != ShizukuStatus.READY) return
        bindingInProgress = true
        runCatching {
            Shizuku.bindUserService(userServiceArgs, serviceConnection)
        }.onFailure {
            bindingInProgress = false
        }
    }

    private fun refreshStatusFast(): ShizukuStatus {
        return when {
            !isShizukuInstalled() -> ShizukuStatus.NOT_INSTALLED
            !Shizuku.pingBinder() -> ShizukuStatus.NOT_RUNNING
            Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED ->
                ShizukuStatus.PERMISSION_REQUIRED
            else -> ShizukuStatus.READY
        }
    }

    suspend fun runShell(command: String): ShellResult = withContext(Dispatchers.IO) {
        if (refreshStatus() != ShizukuStatus.READY) {
            return@withContext ShellResult(false, "Shizuku is not ready")
        }

        val service = shellService ?: waitForService()
        if (service == null) {
            return@withContext ShellResult(false, "Could not bind Shizuku shell service")
        }

        return@withContext try {
            val out = service.exec(command)
            val failed = out.startsWith("ERROR:") || out.startsWith("EXIT:")
            ShellResult(!failed, out)
        } catch (t: Throwable) {
            shellService = null
            ShellResult(false, t.message ?: "Execution failed")
        }
    }

    private suspend fun waitForService(): IShellExecutor? = withTimeoutOrNull(3500L) {
        suspendCancellableCoroutine { cont ->
            val tempConnection = object : ServiceConnection {
                override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
                    val exec = IShellExecutor.Stub.asInterface(service)
                    shellService = exec
                    bindingInProgress = false
                    if (cont.isActive) cont.resume(exec)
                }

                override fun onServiceDisconnected(name: ComponentName?) {
                    shellService = null
                    bindingInProgress = false
                    if (cont.isActive) cont.resume(null)
                }
            }
            bindingInProgress = true
            runCatching {
                Shizuku.bindUserService(userServiceArgs, tempConnection)
            }.onFailure {
                bindingInProgress = false
                if (cont.isActive) cont.resume(null)
            }
        }
    }
}
