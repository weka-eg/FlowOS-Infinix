package com.flowos.infinix.core.prefs

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "flowos_settings")

enum class AppLanguage { AR, EN }
enum class AppThemeMode { SYSTEM, DARK, LIGHT }

data class FlowSettingsState(
    val language: AppLanguage = AppLanguage.AR,
    val themeMode: AppThemeMode = AppThemeMode.SYSTEM,
    val dockPackages: Set<String> = emptySet(),
    val hiddenPackages: Set<String> = emptySet(),
    val animationSpeedMultiplier: Float = 1.0f,
    val edgeSwitcherEnabled: Boolean = false,
    val showAppLabels: Boolean = true,
    val blurIntensity: Float = 0.85f
)

class FlowPreferences(private val context: Context) {

    private object Keys {
        val LANGUAGE = stringPreferencesKey("language")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val DOCK_PACKAGES = stringSetPreferencesKey("dock_packages")
        val HIDDEN_PACKAGES = stringSetPreferencesKey("hidden_packages")
        val ANIMATION_MULTIPLIER = floatPreferencesKey("animation_multiplier")
        val EDGE_SWITCHER = booleanPreferencesKey("edge_switcher")
        val SHOW_APP_LABELS = booleanPreferencesKey("show_app_labels")
        val BLUR_INTENSITY = floatPreferencesKey("blur_intensity")
    }

    val settingsFlow: Flow<FlowSettingsState> = context.dataStore.data.map { prefs ->
        val lang = prefs[Keys.LANGUAGE]?.let { runCatching { AppLanguage.valueOf(it) }.getOrNull() }
            ?: AppLanguage.AR
        val theme = prefs[Keys.THEME_MODE]?.let { runCatching { AppThemeMode.valueOf(it) }.getOrNull() }
            ?: AppThemeMode.SYSTEM

        FlowSettingsState(
            language = lang,
            themeMode = theme,
            dockPackages = prefs[Keys.DOCK_PACKAGES] ?: emptySet(),
            hiddenPackages = prefs[Keys.HIDDEN_PACKAGES] ?: emptySet(),
            animationSpeedMultiplier = prefs[Keys.ANIMATION_MULTIPLIER] ?: 1.0f,
            edgeSwitcherEnabled = prefs[Keys.EDGE_SWITCHER] ?: false,
            showAppLabels = prefs[Keys.SHOW_APP_LABELS] ?: true,
            blurIntensity = prefs[Keys.BLUR_INTENSITY] ?: 0.85f
        )
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.dataStore.edit { it[Keys.LANGUAGE] = language.name }
    }

    suspend fun setThemeMode(mode: AppThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setDockPackages(packages: Set<String>) {
        context.dataStore.edit { it[Keys.DOCK_PACKAGES] = packages }
    }

    suspend fun toggleHiddenPackage(packageName: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.HIDDEN_PACKAGES]?.toMutableSet() ?: mutableSetOf()
            if (!current.add(packageName)) current.remove(packageName)
            prefs[Keys.HIDDEN_PACKAGES] = current
        }
    }

    suspend fun setAnimationMultiplier(value: Float) {
        context.dataStore.edit { it[Keys.ANIMATION_MULTIPLIER] = value.coerceIn(0.4f, 1.5f) }
    }

    suspend fun setEdgeSwitcherEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.EDGE_SWITCHER] = enabled }
    }

    suspend fun setShowAppLabels(show: Boolean) {
        context.dataStore.edit { it[Keys.SHOW_APP_LABELS] = show }
    }
}
