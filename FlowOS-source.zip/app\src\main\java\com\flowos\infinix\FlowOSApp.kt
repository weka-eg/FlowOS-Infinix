package com.flowos.infinix

import android.app.Application
import android.os.Build
import com.flowos.infinix.core.apps.AppRepository
import com.flowos.infinix.core.prefs.FlowPreferences
import com.flowos.infinix.core.shizuku.ShizukuBridge
import com.flowos.infinix.core.storage.StorageAnalyzer
import com.flowos.infinix.core.systemui.SystemUiFixer
import org.lsposed.hiddenapibypass.HiddenApiBypass

class FlowOSApp : Application() {

    lateinit var preferences: FlowPreferences
        private set
    lateinit var shizukuBridge: ShizukuBridge
        private set
    lateinit var appRepository: AppRepository
        private set
    lateinit var systemUiFixer: SystemUiFixer
        private set
    lateinit var storageAnalyzer: StorageAnalyzer
        private set

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            runCatching { HiddenApiBypass.addHiddenApiExemptions("L") }
        }

        preferences = FlowPreferences(this)
        shizukuBridge = ShizukuBridge(this)
        shizukuBridge.registerListeners()

        appRepository = AppRepository(this)
        systemUiFixer = SystemUiFixer(this, shizukuBridge)
        storageAnalyzer = StorageAnalyzer(this, shizukuBridge)
    }

    override fun onTerminate() {
        shizukuBridge.unregisterListeners()
        super.onTerminate()
    }
}
