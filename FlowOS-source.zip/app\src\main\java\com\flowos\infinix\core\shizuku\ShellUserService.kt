package com.flowos.infinix.core.shizuku

import com.flowos.infinix.IShellExecutor
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlin.system.exitProcess

/**
 * Runs inside the Shizuku privileged process (ADB shell UID 2000).
 * Executes diagnostics and reversible XOS system optimizations without Root.
 */
class ShellUserService : IShellExecutor.Stub() {

    override fun exec(command: String): String {
        return try {
            val process = ProcessBuilder("sh", "-c", command)
                .redirectErrorStream(true)
                .start()
            val output = StringBuilder()
            BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    output.appendLine(line)
                }
            }
            val code = process.waitFor()
            if (code != 0 && output.isEmpty()) {
                "EXIT:$code"
            } else {
                output.toString().trimEnd()
            }
        } catch (t: Throwable) {
            "ERROR:${t.message ?: "Unknown shell error"}"
        }
    }

    override fun destroy() {
        exitProcess(0)
    }
}
