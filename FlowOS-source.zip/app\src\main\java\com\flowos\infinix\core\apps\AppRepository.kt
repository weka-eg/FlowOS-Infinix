package com.flowos.infinix.core.apps

import android.app.ActivityOptions
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Process
import android.provider.Settings
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

enum class AppCategory {
    SOCIAL,
    MEDIA,
    GAMES,
    PRODUCTIVITY,
    TOOLS,
    SYSTEM
}

data class AppEntry(
    val packageName: String,
    val activityName: String,
    val label: String,
    val category: AppCategory,
    val isSystemApp: Boolean
)

class AppRepository(private val context: Context) {

    private val _apps = MutableStateFlow<List<AppEntry>>(emptyList())
    val apps: StateFlow<List<AppEntry>> = _apps.asStateFlow()

    private val _recentApps = MutableStateFlow<List<AppEntry>>(emptyList())
    val recentApps: StateFlow<List<AppEntry>> = _recentApps.asStateFlow()

    private val iconCache = ConcurrentHashMap<String, ImageBitmap>()
    private val localLaunchHistory = mutableListOf<String>()

    suspend fun loadApps() = withContext(Dispatchers.IO) {
        val launcherApps = context.getSystemService(LauncherApps::class.java)
        val pm = context.packageManager
        val list = mutableListOf<AppEntry>()
        val seenPackages = HashSet<String>()

        if (launcherApps != null) {
            val activities = runCatching {
                launcherApps.getActivityList(null, Process.myUserHandle())
            }.getOrDefault(emptyList())

            for (info in activities) {
                val pkg = info.applicationInfo.packageName
                if (pkg == context.packageName) continue
                if (!seenPackages.add(pkg)) continue

                val label = info.label?.toString()?.trim().orEmpty().ifEmpty { pkg }
                val isSystem = (info.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                val category = classifyApp(info.applicationInfo, pkg)

                list.add(
                    AppEntry(
                        packageName = pkg,
                        activityName = info.componentName.className,
                        label = label,
                        category = category,
                        isSystemApp = isSystem
                    )
                )

                if (!iconCache.containsKey(pkg)) {
                    runCatching {
                        val drawable = info.getBadgedIcon(0)
                        iconCache[pkg] = drawableToImageBitmap(drawable)
                    }
                }
            }
        }

        if (list.isEmpty()) {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val resolved = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            for (ri in resolved) {
                val pkg = ri.activityInfo.packageName
                if (pkg == context.packageName) continue
                if (!seenPackages.add(pkg)) continue

                val appInfo = ri.activityInfo.applicationInfo
                val label = ri.loadLabel(pm).toString().trim().ifEmpty { pkg }
                val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                list.add(
                    AppEntry(
                        packageName = pkg,
                        activityName = ri.activityInfo.name,
                        label = label,
                        category = classifyApp(appInfo, pkg),
                        isSystemApp = isSystem
                    )
                )
                if (!iconCache.containsKey(pkg)) {
                    runCatching {
                        iconCache[pkg] = drawableToImageBitmap(ri.loadIcon(pm))
                    }
                }
            }
        }

        val sorted = list.sortedBy { it.label.lowercase() }
        _apps.value = sorted
        refreshRecentApps(sorted)
    }

    suspend fun refreshRecentApps(allApps: List<AppEntry> = _apps.value) = withContext(Dispatchers.IO) {
        if (allApps.isEmpty()) return@withContext
        val byPkg = allApps.associateBy { it.packageName }
        val result = mutableListOf<AppEntry>()
        val seen = HashSet<String>()

        if (hasUsageStatsPermission()) {
            val usm = context.getSystemService(UsageStatsManager::class.java)
            val end = System.currentTimeMillis()
            val start = end - 1000L * 60 * 60 * 24 // last 24h
            val stats = runCatching {
                usm?.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end)
            }.getOrNull().orEmpty()

            stats.filter { it.lastTimeUsed > 0 && it.packageName != context.packageName }
                .sortedByDescending { it.lastTimeUsed }
                .forEach { stat ->
                    val entry = byPkg[stat.packageName]
                    if (entry != null && seen.add(entry.packageName)) {
                        result.add(entry)
                    }
                }
        }

        // Merge local launch history at the front so newly switched apps always appear immediately
        synchronized(localLaunchHistory) {
            for (pkg in localLaunchHistory) {
                val entry = byPkg[pkg]
                if (entry != null && seen.add(pkg)) {
                    result.add(0, entry)
                }
            }
        }

        if (result.isEmpty()) {
            // Fallback: pick common user apps so the Quick Switcher preview is useful out of the box
            result.addAll(allApps.filter { !it.isSystemApp }.take(8))
        }

        _recentApps.value = result.take(12)
    }

    fun getIcon(packageName: String): ImageBitmap? {
        iconCache[packageName]?.let { return it }
        return runCatching {
            val drawable = context.packageManager.getApplicationIcon(packageName)
            val bmp = drawableToImageBitmap(drawable)
            iconCache[packageName] = bmp
            bmp
        }.getOrNull()
    }

    fun launchApp(
        entry: AppEntry,
        hostView: android.view.View? = null,
        sourceRect: Rect? = null
    ): Boolean {
        synchronized(localLaunchHistory) {
            localLaunchHistory.remove(entry.packageName)
            localLaunchHistory.add(0, entry.packageName)
            if (localLaunchHistory.size > 15) {
                localLaunchHistory.removeAt(localLaunchHistory.lastIndex)
            }
        }

        val pm = context.packageManager
        val intent = pm.getLaunchIntentForPackage(entry.packageName)?.apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        } ?: return false

        val options = if (hostView != null && sourceRect != null && sourceRect.width() > 0 && sourceRect.height() > 0) {
            ActivityOptions.makeScaleUpAnimation(
                hostView,
                sourceRect.left,
                sourceRect.top,
                sourceRect.width(),
                sourceRect.height()
            )
        } else {
            ActivityOptions.makeBasic()
        }

        return runCatching {
            context.startActivity(intent, options.toBundle())
            true
        }.getOrDefault(false)
    }

    fun openAppInfo(packageName: String) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { context.startActivity(intent) }
    }

    fun uninstallApp(packageName: String) {
        val intent = Intent(Intent.ACTION_DELETE).apply {
            data = Uri.fromParts("package", packageName, null)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { context.startActivity(intent) }
    }

    fun isDefaultLauncher(): Boolean {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val resolveInfo = context.packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
        return resolveInfo?.activityInfo?.packageName == context.packageName
    }

    fun openDefaultLauncherChooser() {
        val intent = Intent(Settings.ACTION_HOME_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { context.startActivity(intent) }
    }

    fun hasUsageStatsPermission(): Boolean {
        val appOps = context.getSystemService(AppOpsManager::class.java) ?: return false
        val mode = appOps.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            context.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun classifyApp(info: ApplicationInfo, pkg: String): AppCategory {
        val lower = pkg.lowercase()
        when {
            lower.contains("whatsapp") || lower.contains("telegram") ||
                lower.contains("instagram") || lower.contains("facebook") ||
                lower.contains("snapchat") || lower.contains("twitter") ||
                lower.contains("discord") || lower.contains("tiktok") ||
                lower.contains("messenger") -> return AppCategory.SOCIAL

            lower.contains("youtube") || lower.contains("spotify") ||
                lower.contains("netflix") || lower.contains("vlc") ||
                lower.contains("gallery") || lower.contains("camera") ||
                lower.contains("music") || lower.contains("video") -> return AppCategory.MEDIA

            lower.contains("game") || lower.contains("pubg") ||
                lower.contains("freefire") || lower.contains("roblox") ||
                lower.contains("minecraft") -> return AppCategory.GAMES
        }

        return when (info.category) {
            ApplicationInfo.CATEGORY_SOCIAL -> AppCategory.SOCIAL
            ApplicationInfo.CATEGORY_VIDEO,
            ApplicationInfo.CATEGORY_AUDIO,
            ApplicationInfo.CATEGORY_IMAGE -> AppCategory.MEDIA
            ApplicationInfo.CATEGORY_GAME -> AppCategory.GAMES
            ApplicationInfo.CATEGORY_PRODUCTIVITY -> AppCategory.PRODUCTIVITY
            ApplicationInfo.CATEGORY_MAPS,
            ApplicationInfo.CATEGORY_NEWS -> AppCategory.TOOLS
            else -> if ((info.flags and ApplicationInfo.FLAG_SYSTEM) != 0) AppCategory.SYSTEM else AppCategory.TOOLS
        }
    }

    private fun drawableToImageBitmap(drawable: Drawable): ImageBitmap {
        val targetSize = 144
        if (drawable is BitmapDrawable && drawable.bitmap != null) {
            val bmp = drawable.bitmap
            val scaled = if (bmp.width > targetSize || bmp.height > targetSize) {
                Bitmap.createScaledBitmap(bmp, targetSize, targetSize, true)
            } else {
                bmp
            }
            return scaled.asImageBitmap()
        }

        val width = drawable.intrinsicWidth.takeIf { it > 0 }?.coerceAtMost(targetSize) ?: targetSize
        val height = drawable.intrinsicHeight.takeIf { it > 0 }?.coerceAtMost(targetSize) ?: targetSize
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bitmap.asImageBitmap()
    }
}
