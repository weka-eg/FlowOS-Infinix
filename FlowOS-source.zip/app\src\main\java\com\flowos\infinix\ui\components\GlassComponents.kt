package com.flowos.infinix.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.flowos.infinix.core.i18n.LocalStrings
import com.flowos.infinix.core.shizuku.ShizukuStatus
import com.flowos.infinix.core.theme.FlowDimens
import com.flowos.infinix.core.theme.LocalGlassPalette
import java.util.Locale

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = FlowDimens.CardRadius,
    elevated: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val palette = LocalGlassPalette.current
    val shape = RoundedCornerShape(cornerRadius)
    val bg = if (elevated) palette.glassSurfaceElevated else palette.glassSurface

    val baseModifier = modifier
        .clip(shape)
        .background(bg)
        .border(1.dp, palette.glassBorder, shape)
        .let { if (onClick != null) it.clickable(onClick = onClick) else it }
        .padding(16.dp)

    Column(modifier = baseModifier, content = content)
}

@Composable
fun ShizukuStatusCard(
    status: ShizukuStatus,
    onGrantClick: () -> Unit,
    onOpenGuide: () -> Unit,
    modifier: Modifier = Modifier
) {
    val s = LocalStrings.current
    val palette = LocalGlassPalette.current

    val (accent, icon, text) = when (status) {
        ShizukuStatus.READY -> Triple(palette.successGreen, Icons.Rounded.CheckCircle, s.shizukuReady)
        ShizukuStatus.PERMISSION_REQUIRED -> Triple(palette.warningAmber, Icons.Rounded.Security, s.shizukuNeedsPermission)
        ShizukuStatus.NOT_RUNNING -> Triple(palette.warningAmber, Icons.Rounded.Warning, s.shizukuNotRunning)
        ShizukuStatus.NOT_INSTALLED -> Triple(palette.dangerRed, Icons.Rounded.Info, s.shizukuNotInstalled)
    }

    GlassCard(modifier = modifier.fillMaxWidth()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(accent.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(12.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.weight(1f)
            )
        }

        if (status != ShizukuStatus.READY) {
            Spacer(Modifier.height(12.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (status == ShizukuStatus.PERMISSION_REQUIRED) {
                    Button(
                        onClick = onGrantClick,
                        colors = ButtonDefaults.buttonColors(containerColor = palette.accentBlue),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(s.shizukuGrantBtn)
                    }
                }
                OutlinedButton(
                    onClick = onOpenGuide,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(s.shizukuSetupGuideBtn)
                }
            }
        }
    }
}

@Composable
fun ShizukuSetupDialog(
    isInstalled: Boolean,
    onDismiss: () -> Unit,
    onOpenShizuku: () -> Unit,
    onOpenDevOptions: () -> Unit
) {
    val s = LocalStrings.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(s.shizukuGuideTitle, style = MaterialTheme.typography.titleMedium)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                s.shizukuGuideSteps.forEach { step ->
                    Text(step, style = MaterialTheme.typography.bodyMedium)
                }
            }
        },
        confirmButton = {
            if (isInstalled) {
                Button(onClick = {
                    onOpenShizuku()
                    onDismiss()
                }) {
                    Text(s.openShizukuApp)
                }
            } else {
                Button(onClick = {
                    onOpenDevOptions()
                    onDismiss()
                }) {
                    Text(s.openDeveloperOptions)
                }
            }
        },
        dismissButton = {
            Row {
                if (isInstalled) {
                    TextButton(onClick = {
                        onOpenDevOptions()
                    }) {
                        Text(s.openDeveloperOptions)
                    }
                }
                TextButton(onClick = onDismiss) {
                    Text(s.close)
                }
            }
        }
    )
}

fun formatBytes(bytes: Long): String {
    if (bytes <= 0L) return "0 B"
    val kb = 1024.0
    val mb = kb * 1024.0
    val gb = mb * 1024.0
    return when {
        bytes >= gb -> String.format(Locale.US, "%.2f GB", bytes / gb)
        bytes >= mb -> String.format(Locale.US, "%.1f MB", bytes / mb)
        bytes >= kb -> String.format(Locale.US, "%.0f KB", bytes / kb)
        else -> "$bytes B"
    }
}

@Composable
fun StatusPill(
    text: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.16f))
            .border(1.dp, color.copy(alpha = 0.35f), RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = text,
            color = color,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold
        )
    }
}
