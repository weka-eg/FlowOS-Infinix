package com.flowos.infinix.core.systemui

import android.app.ActivityManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import com.flowos.infinix.core.shizuku.ShizukuBridge
import com.flowos.infinix.core.shizuku.ShizukuStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class XosPackageStatus(
    val spec: XosPackageSpec,
    val isEnabled: Boolean
)

data class HeavyProcessInfo(
    val packageName: String,
    val label: String,
    val memoryMb: Int
)

data class SystemDiagnostics(
    val deviceModel: String,
    val manufacturer: String,
    val androidVersion: String,
    val isInfinixDevice: Boolean,
    val totalRamMb: Long,
    val availableRamMb: Long,
    val isLowMemory: Boolean,
    val windowAnimationScale: Float,
    val transitionAnimationScale: Float,
    val animatorDurationScale: Float,
    val systemUiMemoryMb: Int?,
    val xosPackages: List<XosPackageStatus>,
    val heavyProcesses: List<HeavyProcessInfo>
)

data class SmartFixReport(
    val stepsCompleted: List<String>,
    val freedRamMb: Long,
    val usedShizuku: Boolean
)

class SystemUiFixer(
    private val context: Context,
    private val shizuku: ShizukuBridge
) {

    suspend fun collectDiagnostics(): SystemDiagnostics = withContext(Dispatchers.IO) {
        val am = context.getSystemService(ActivityManager::class.java)
        val memInfo = ActivityManager.MemoryInfo()
        am?.getMemoryInfo(memInfo)

        val totalMb = memInfo.totalMem / (1024 * 1024)
        val availMb = memInfo.availMem / (1024 * 1024)

        val windowScale = readGlobalFloat(Settings.Global.WINDOW_ANIMATION_SCALE, 1.0f)
        val transScale = readGlobalFloat(Settings.Global.TRANSITION_ANIMATION_SCALE, 1.0f)
        val animScale = readGlobalFloat(Settings.Global.ANIMATOR_DURATION_SCALE, 1.0f)

        val pm = context.packageManager
        val disabledSet = if (shizuku.status.value == ShizukuStatus.READY) {
            val res = shizuku.runShell("pm list packages -d")
            if (res.success) {
                res.output.lines()
                    .mapNotNull { it.removePrefix("package:").trim().takeIf { p -> p.isNotEmpty() } }
                    .toSet()
            } else {
                emptySet()
            }
        } else {
            emptySet()
        }

        val xosDetected = mutableListOf<XosPackageStatus>()
        for (spec in XosPackageCatalog.knownPackages) {
            val appInfo = runCatching {
                pm.getApplicationInfo(spec.packageName, PackageManager.MATCH_DISABLED_COMPONENTS)
            }.getOrNull()
            if (appInfo != null) {
                val enabled = if (disabledSet.isNotEmpty()) {
                    !disabledSet.contains(spec.packageName)
                } else {
                    appInfo.enabled
                }
                xosDetected.add(XosPackageStatus(spec = spec, isEnabled = enabled))
            }
        }

        var systemUiMb: Int? = null
        val heavyList = mutableListOf<HeavyProcessInfo>()

        if (shizuku.status.value == ShizukuStatus.READY) {
            val psRes = shizuku.runShell("ps -A -o RSS,NAME")
            if (psRes.success) {
                val pmMap = HashMap<String, String>()
                psRes.output.lines().drop(1).forEach { line ->
                    val parts = line.trim().split(Regex("\\s+"), limit = 2)
                    if (parts.size == 2) {
                        val rssKb = parts[0].toLongOrNull() ?: return@forEach
                        val procName = parts[1].trim()
                        val mb = (rssKb / 1024L).toInt()
                        if (procName == "com.android.systemui") {
                            systemUiMb = mb
                        } else if (procName.contains('.') &&
                            !procName.startsWith("com.android.") &&
                            procName != context.packageName &&
                            mb >= 45
                        ) {
                            val basePkg = procName.substringBefore(':')
                            if (!pmMap.containsKey(basePkg)) {
                                val appInfo = runCatching { pm.getApplicationInfo(basePkg, 0) }.getOrNull()
                                if (appInfo != null && (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) == 0) {
                                    val label = pm.getApplicationLabel(appInfo).toString()
                                    pmMap[basePkg] = label
                                    heavyList.add(HeavyProcessInfo(basePkg, label, mb))
                                }
                            }
                        }
                    }
                }
            }
        }

        SystemDiagnostics(
            deviceModel = Build.MODEL.orEmpty(),
            manufacturer = Build.MANUFACTURER.orEmpty(),
            androidVersion = Build.VERSION.RELEASE.orEmpty(),
            isInfinixDevice = Build.MANUFACTURER.equals("INFINIX", ignoreCase = true) ||
                Build.BRAND.equals("Infinix", ignoreCase = true),
            totalRamMb = totalMb,
            availableRamMb = availMb,
            isLowMemory = memInfo.lowMemory,
            windowAnimationScale = windowScale,
            transitionAnimationScale = transScale,
            animatorDurationScale = animScale,
            systemUiMemoryMb = systemUiMb,
            xosPackages = xosDetected,
            heavyProcesses = heavyList.sortedByDescending { it.memoryMb }.take(8)
        )
    }

    suspend fun runOneTapSmartFix(
        isArabic: Boolean,
        onStep: (String) -> Unit
    ): SmartFixReport = withContext(Dispatchers.IO) {
        val am = context.getSystemService(ActivityManager::class.java)
        val beforeMem = ActivityManager.MemoryInfo()
        am?.getMemoryInfo(beforeMem)
        val beforeMb = beforeMem.availMem / (1024 * 1024)

        val log = mutableListOf<String>()
        val hasShizuku = shizuku.status.value == ShizukuStatus.READY

        // Step 1: Trim background processes via standard API
        onStep(if (isArabic) "تصفية العمليات الخلفية غير النشطة..." else "Trimming idle background processes...")
        val pm = context.packageManager
        val installed = pm.getInstalledApplications(0)
        for (app in installed) {
            if (app.packageName != context.packageName && (app.flags and ApplicationInfo.FLAG_SYSTEM) == 0) {
                runCatching { am?.killBackgroundProcesses(app.packageName) }
            }
        }
        log.add(if (isArabic) "✓ تم إيقاف العمليات الخلفية الخاملة" else "✓ Killed idle background processes")

        if (hasShizuku) {
            // Step 2: Trim system & app caches
            onStep(if (isArabic) "تنظيف كاشات التطبيقات والنظام عبر Shizuku..." else "Trimming system & app caches via Shizuku...")
            val trimRes = shizuku.runShell("pm trim-caches 1024G")
            if (trimRes.success) {
                log.add(if (isArabic) "✓ تم تفريغ كاشات النظام (pm trim-caches)" else "✓ System & app caches trimmed")
            }

            // Step 3: Tune 120Hz smooth animation scales
            onStep(if (isArabic) "ضبط مقياس الحركة على 0.75x لسلاسة 120Hz..." else "Tuning animation scales to 0.75x for 120Hz fluidity...")
            setAnimationScalesInternal(0.75f)
            log.add(if (isArabic) "✓ تم ضبط سرعة الانيمشن على 0.75x" else "✓ Animation scales tuned to 0.75x")

            // Step 4: Enable Android cached app freezer & compact memory
            onStep(if (isArabic) "تفعيل مجمد التطبيقات الخلفية لتخفيف الحمل عن System UI..." else "Enabling cached apps freezer to relieve System UI...")
            shizuku.runShell("settings put global cached_apps_freezer enabled")
            shizuku.runShell("am kill-all")
            log.add(if (isArabic) "✓ تم تفعيل مجمد العمليات وتقليل استهلاك الرام" else "✓ Cached app freezer enabled & RAM compacted")
        } else {
            log.add(
                if (isArabic) "ℹ Shizuku غير متصل: تم تنفيذ تحسين الرام الأساسي فقط"
                else "ℹ Shizuku not connected: basic RAM cleanup applied"
            )
        }

        val afterMem = ActivityManager.MemoryInfo()
        am?.getMemoryInfo(afterMem)
        val afterMb = afterMem.availMem / (1024 * 1024)
        val freed = (afterMb - beforeMb).coerceAtLeast(0L)

        SmartFixReport(
            stepsCompleted = log,
            freedRamMb = freed,
            usedShizuku = hasShizuku
        )
    }

    suspend fun setAnimationScales(scale: Float): Boolean = withContext(Dispatchers.IO) {
        if (shizuku.status.value != ShizukuStatus.READY) return@withContext false
        setAnimationScalesInternal(scale)
    }

    private suspend fun setAnimationScalesInternal(scale: Float): Boolean {
        val formatted = String.format(java.util.Locale.US, "%.2f", scale.coerceIn(0f, 1.5f))
        val cmd = "settings put global window_animation_scale $formatted && " +
            "settings put global transition_animation_scale $formatted && " +
            "settings put global animator_duration_scale $formatted"
        return shizuku.runShell(cmd).success
    }

    suspend fun toggleXosPackage(packageName: String, freeze: Boolean): Boolean = withContext(Dispatchers.IO) {
        if (shizuku.status.value != ShizukuStatus.READY) return@withContext false
        val cmd = if (freeze) {
            "pm disable-user --user 0 $packageName"
        } else {
            "pm enable $packageName"
        }
        shizuku.runShell(cmd).success
    }

    suspend fun restartSystemUi(): Boolean = withContext(Dispatchers.IO) {
        if (shizuku.status.value != ShizukuStatus.READY) return@withContext false
        // Try standard killall / pkill so init/Zygote immediately respawns com.android.systemui cleanly
        val res = shizuku.runShell("pkill -f com.android.systemui || killall com.android.systemui")
        res.success
    }

    suspend fun forceStopPackage(packageName: String): Boolean = withContext(Dispatchers.IO) {
        if (shizuku.status.value != ShizukuStatus.READY) return@withContext false
        shizuku.runShell("am force-stop $packageName").success
    }

    private fun readGlobalFloat(key: String, default: Float): Float {
        return runCatching {
            Settings.Global.getFloat(context.contentResolver, key, default)
        }.getOrDefault(default)
    }
}
