package com.flowos.infinix.core.systemui

enum class PackageFreezeRisk {
    SAFE,
    MODERATE
}

data class XosPackageSpec(
    val packageName: String,
    val titleAr: String,
    val titleEn: String,
    val reasonAr: String,
    val reasonEn: String,
    val risk: PackageFreezeRisk
)

/**
 * Curated list of Transsion / Infinix XOS background packages that frequently
 * consume RAM, show background overlays, or trigger "System UI isn't responding" ANRs.
 * All operations via FlowOS use reversible `pm disable-user` (no permanent deletion).
 */
object XosPackageCatalog {
    val knownPackages: List<XosPackageSpec> = listOf(
        XosPackageSpec(
            packageName = "com.transsion.smartpanel",
            titleAr = "الشريط الجانبي الذكي (Smart Panel)",
            titleEn = "XOS Smart Panel Overlay",
            reasonAr = "يعمل كطبقة عائمة مستمرة فوق التطبيقات وقد يسبب تهنيج System UI عند السحب",
            reasonEn = "Runs a persistent window overlay that can stall System UI input dispatch",
            risk = PackageFreezeRisk.SAFE
        ),
        XosPackageSpec(
            packageName = "com.transsion.palmstore",
            titleAr = "متجر Palm Store",
            titleEn = "Palm Store",
            reasonAr = "يرسل إشعارات ترويجية ويفحص التحديثات في الخلفية بشكل متكرر",
            reasonEn = "Runs background update checks and promotional notification services",
            risk = PackageFreezeRisk.SAFE
        ),
        XosPackageSpec(
            packageName = "com.transsion.aivoiceassistant",
            titleAr = "مساعد Folax الصوتي",
            titleEn = "Folax Voice Assistant",
            reasonAr = "يستهلك رامات في الخلفية لالتقاط اختصارات الصوت والواجهة",
            reasonEn = "Holds background memory listeners for voice triggers",
            risk = PackageFreezeRisk.SAFE
        ),
        XosPackageSpec(
            packageName = "com.transsion.xclub",
            titleAr = "مجتمع XClub",
            titleEn = "XClub Community",
            reasonAr = "تطبيق مجتمعي غير ضروري يعمل في الخلفية",
            reasonEn = "Non-essential social/community app running background syncs",
            risk = PackageFreezeRisk.SAFE
        ),
        XosPackageSpec(
            packageName = "com.transsion.carlcare",
            titleAr = "خدمة Carlcare",
            titleEn = "Carlcare Support",
            reasonAr = "خدمة دعم فني تعمل أحياناً لجمع تشخيصات في الخلفية",
            reasonEn = "Support service running periodic background checks",
            risk = PackageFreezeRisk.SAFE
        ),
        XosPackageSpec(
            packageName = "com.transsion.hilauncher",
            titleAr = "لانشر XOS الافتراضي (HiLauncher / XOS Launcher)",
            titleEn = "Default XOS Launcher",
            reasonAr = "يفضل تجميده فقط بعد تعيين FlowOS كلانشر افتراضي لتجنب تعارض الرامات",
            reasonEn = "Freeze only AFTER setting FlowOS as default launcher to save RAM",
            risk = PackageFreezeRisk.MODERATE
        ),
        XosPackageSpec(
            packageName = "com.transsion.xoslauncher",
            titleAr = "واجهة XOS Launcher",
            titleEn = "XOS Launcher",
            reasonAr = "يفضل تجميده فقط بعد تعيين FlowOS كلانشر افتراضي لتخفيف الرامات",
            reasonEn = "Freeze only AFTER setting FlowOS as default launcher",
            risk = PackageFreezeRisk.MODERATE
        ),
        XosPackageSpec(
            packageName = "com.transsion.plat.appupdate",
            titleAr = "محدث تطبيقات النظام (AppUpdate)",
            titleEn = "Transsion App Updater",
            reasonAr = "يفحص تحديثات تطبيقات إنفنكس باستمرار في الخلفية",
            reasonEn = "Periodically polls for vendor app updates in background",
            risk = PackageFreezeRisk.SAFE
        ),
        XosPackageSpec(
            packageName = "com.transsion.magicshow",
            titleAr = "مؤثرات Magic Show / Video Beauty",
            titleEn = "Magic Show Overlay",
            reasonAr = "خدمة فلاتر مكالمات الفيديو التي تبقى محملة مع خدمات الواجهة",
            reasonEn = "Video call beauty overlay service staying resident in memory",
            risk = PackageFreezeRisk.SAFE
        ),
        XosPackageSpec(
            packageName = "com.transsion.wezone",
            titleAr = "WeZone / AHA Games",
            titleEn = "WeZone / AHA Games",
            reasonAr = "ألعاب وإشعارات ترويجية مدمجة تستهلك مساحة ورامات",
            reasonEn = "Preloaded game hub generating background notifications",
            risk = PackageFreezeRisk.SAFE
        ),
        XosPackageSpec(
            packageName = "com.transsion.phoenix",
            titleAr = "متصفح Phoenix",
            titleEn = "Phoenix Browser",
            reasonAr = "متصفح مدمج يعمل بخدمات إشعارات وتنزيل في الخلفية",
            reasonEn = "Preloaded browser with background news & push services",
            risk = PackageFreezeRisk.SAFE
        ),
        XosPackageSpec(
            packageName = "com.transsion.healthlife",
            titleAr = "My Health",
            titleEn = "My Health",
            reasonAr = "تطبيق تتبع خطوات يعمل بمستشعرات مستمرة في الخلفية",
            reasonEn = "Background step-counter sensor service",
            risk = PackageFreezeRisk.MODERATE
        )
    )
}
