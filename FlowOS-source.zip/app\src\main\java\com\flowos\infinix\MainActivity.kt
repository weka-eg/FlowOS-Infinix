package com.flowos.infinix

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.HealthAndSafety
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.flowos.infinix.core.i18n.LocalStrings
import com.flowos.infinix.core.i18n.stringsFor
import com.flowos.infinix.core.launcher.QuickSwitcherOverlayService
import com.flowos.infinix.core.prefs.AppLanguage
import com.flowos.infinix.core.prefs.FlowSettingsState
import com.flowos.infinix.core.storage.AppStorageItem
import com.flowos.infinix.core.storage.DeepStorageScanResult
import com.flowos.infinix.core.storage.StorageOverview
import com.flowos.infinix.core.systemui.SmartFixReport
import com.flowos.infinix.core.systemui.SystemDiagnostics
import com.flowos.infinix.core.theme.FlowOSTheme
import com.flowos.infinix.core.theme.LocalGlassPalette
import com.flowos.infinix.ui.fixer.SystemFixerScreen
import com.flowos.infinix.ui.launcher.LauncherScreen
import com.flowos.infinix.ui.settings.FlowSettingsScreen
import com.flowos.infinix.ui.storage.StorageAnalyzerScreen
import kotlinx.coroutines.launch

private enum class FlowTab {
    LAUNCHER,
    SYSTEM_FIX,
    STORAGE,
    SETTINGS
}

class MainActivity : ComponentActivity() {

    private var openSwitcherSignal by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (intent?.action == QuickSwitcherOverlayService.ACTION_OPEN_SWITCHER) {
            openSwitcherSignal = true
        }

        val app = application as FlowOSApp

        setContent {
            val settings by app.preferences.settingsFlow.collectAsState(initial = FlowSettingsState())
            val shizukuStatus by app.shizukuBridge.status.collectAsState()
            val apps by app.appRepository.apps.collectAsState()
            val recentApps by app.appRepository.recentApps.collectAsState()

            val strings = remember(settings.language) { stringsFor(settings.language) }
            val layoutDirection = if (settings.language == AppLanguage.AR) LayoutDirection.Rtl else LayoutDirection.Ltr

            val scope = rememberCoroutineScope()
            var currentTab by remember { mutableStateOf(FlowTab.LAUNCHER) }
            var showQuickSwitcher by remember { mutableStateOf(false) }

            // System Fixer state
            var diagnostics by remember { mutableStateOf<SystemDiagnostics?>(null) }
            var isFixing by remember { mutableStateOf(false) }
            var currentFixStep by remember { mutableStateOf<String?>(null) }
            var lastFixReport by remember { mutableStateOf<SmartFixReport?>(null) }

            // Storage Analyzer state
            var storageOverview by remember { mutableStateOf<StorageOverview?>(null) }
            var appStorageList by remember { mutableStateOf<List<AppStorageItem>>(emptyList()) }
            var deepScanResult by remember { mutableStateOf<DeepStorageScanResult?>(null) }
            var isScanningStorage by remember { mutableStateOf(false) }
            var isCleaningCaches by remember { mutableStateOf(false) }
            var storageBannerMsg by remember { mutableStateOf<String?>(null) }

            var hasUsageAccess by remember { mutableStateOf(app.storageAnalyzer.hasUsageAccess()) }
            var hasAllFilesAccess by remember { mutableStateOf(app.storageAnalyzer.hasAllFilesAccess()) }
            var isDefaultLauncher by remember { mutableStateOf(app.appRepository.isDefaultLauncher()) }
            var hasOverlayPerm by remember { mutableStateOf(Settings.canDrawOverlays(this@MainActivity)) }

            fun refreshAllData() {
                scope.launch {
                    app.shizukuBridge.refreshStatus()
                    app.appRepository.loadApps()
                    diagnostics = app.systemUiFixer.collectDiagnostics()
                    val (overview, appList) = app.storageAnalyzer.analyzeOverviewAndApps()
                    storageOverview = overview
                    appStorageList = appList
                    hasUsageAccess = app.storageAnalyzer.hasUsageAccess()
                    hasAllFilesAccess = app.storageAnalyzer.hasAllFilesAccess()
                    isDefaultLauncher = app.appRepository.isDefaultLauncher()
                    hasOverlayPerm = Settings.canDrawOverlays(this@MainActivity)
                }
            }

            LaunchedEffect(Unit) {
                refreshAllData()
            }

            LaunchedEffect(openSwitcherSignal) {
                if (openSwitcherSignal) {
                    currentTab = FlowTab.LAUNCHER
                    app.appRepository.refreshRecentApps()
                    showQuickSwitcher = true
                    openSwitcherSignal = false
                }
            }

            val lifecycleOwner = LocalLifecycleOwner.current
            DisposableEffect(lifecycleOwner) {
                val observer = LifecycleEventObserver { _, event ->
                    if (event == Lifecycle.Event.ON_RESUME) {
                        refreshAllData()
                    }
                }
                lifecycleOwner.lifecycle.addObserver(observer)
                onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
            }

            BackHandler(enabled = currentTab != FlowTab.LAUNCHER || showQuickSwitcher) {
                if (showQuickSwitcher) {
                    showQuickSwitcher = false
                } else {
                    currentTab = FlowTab.LAUNCHER
                }
            }

            CompositionLocalProvider(
                LocalStrings provides strings,
                LocalLayoutDirection provides layoutDirection
            ) {
                FlowOSTheme(themeMode = settings.themeMode) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        when (currentTab) {
                            FlowTab.LAUNCHER -> {
                                LauncherScreen(
                                    apps = apps,
                                    recentApps = recentApps,
                                    dockPackages = settings.dockPackages,
                                    showAppLabels = settings.showAppLabels,
                                    animationMultiplier = settings.animationSpeedMultiplier,
                                    availableRamMb = diagnostics?.availableRamMb ?: 0L,
                                    totalRamMb = diagnostics?.totalRamMb ?: 0L,
                                    freeStorageBytes = storageOverview?.freeBytes ?: 0L,
                                    showQuickSwitcher = showQuickSwitcher,
                                    onToggleQuickSwitcher = { open ->
                                        if (open) {
                                            scope.launch { app.appRepository.refreshRecentApps() }
                                        }
                                        showQuickSwitcher = open
                                    },
                                    getIcon = { pkg -> app.appRepository.getIcon(pkg) },
                                    onLaunchApp = { entry, hostView, rect ->
                                        app.appRepository.launchApp(entry, hostView, rect)
                                    },
                                    onToggleDockPin = { pkg ->
                                        scope.launch {
                                            val next = settings.dockPackages.toMutableSet()
                                            if (!next.add(pkg)) next.remove(pkg)
                                            app.preferences.setDockPackages(next.take(4).toSet())
                                        }
                                    },
                                    onOpenAppInfo = { pkg -> app.appRepository.openAppInfo(pkg) },
                                    onUninstallApp = { pkg -> app.appRepository.uninstallApp(pkg) },
                                    onNavigateSystemFix = { currentTab = FlowTab.SYSTEM_FIX },
                                    onNavigateStorage = { currentTab = FlowTab.STORAGE },
                                    onNavigateSettings = { currentTab = FlowTab.SETTINGS }
                                )
                            }

                            FlowTab.SYSTEM_FIX -> {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(MaterialTheme.colorScheme.background)
                                        .statusBarsPadding()
                                        .navigationBarsPadding()
                                ) {
                                    SystemFixerScreen(
                                        isArabic = settings.language == AppLanguage.AR,
                                        shizukuStatus = shizukuStatus,
                                        isShizukuInstalled = app.shizukuBridge.isShizukuInstalled(),
                                        diagnostics = diagnostics,
                                        isFixing = isFixing,
                                        currentFixStep = currentFixStep,
                                        lastFixReport = lastFixReport,
                                        onRefreshDiagnostics = {
                                            scope.launch {
                                                app.shizukuBridge.refreshStatus()
                                                diagnostics = app.systemUiFixer.collectDiagnostics()
                                            }
                                        },
                                        onGrantShizuku = { app.shizukuBridge.requestPermission() },
                                        onOpenShizukuApp = { app.shizukuBridge.openShizukuApp() },
                                        onOpenDevOptions = { app.shizukuBridge.openDeveloperOptions() },
                                        onRunSmartFix = {
                                            scope.launch {
                                                isFixing = true
                                                lastFixReport = app.systemUiFixer.runOneTapSmartFix(
                                                    isArabic = settings.language == AppLanguage.AR,
                                                    onStep = { step -> currentFixStep = step }
                                                )
                                                diagnostics = app.systemUiFixer.collectDiagnostics()
                                                isFixing = false
                                                currentFixStep = null
                                            }
                                        },
                                        onRestartSystemUi = {
                                            scope.launch { app.systemUiFixer.restartSystemUi() }
                                        },
                                        onSetAnimationScale = { scale ->
                                            scope.launch {
                                                app.systemUiFixer.setAnimationScales(scale)
                                                diagnostics = app.systemUiFixer.collectDiagnostics()
                                            }
                                        },
                                        onToggleXosPackage = { pkg, freeze ->
                                            scope.launch {
                                                app.systemUiFixer.toggleXosPackage(pkg, freeze)
                                                diagnostics = app.systemUiFixer.collectDiagnostics()
                                            }
                                        },
                                        onForceStopPackage = { pkg ->
                                            scope.launch {
                                                app.systemUiFixer.forceStopPackage(pkg)
                                                diagnostics = app.systemUiFixer.collectDiagnostics()
                                            }
                                        }
                                    )
                                }
                            }

                            FlowTab.STORAGE -> {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(MaterialTheme.colorScheme.background)
                                        .statusBarsPadding()
                                        .navigationBarsPadding()
                                ) {
                                    StorageAnalyzerScreen(
                                        overview = storageOverview,
                                        appStorageList = appStorageList,
                                        deepScanResult = deepScanResult,
                                        hasUsageAccess = hasUsageAccess,
                                        hasAllFilesAccess = hasAllFilesAccess,
                                        shizukuStatus = shizukuStatus,
                                        isScanning = isScanningStorage,
                                        isCleaningCaches = isCleaningCaches,
                                        statusBannerMessage = storageBannerMsg,
                                        onRequestUsageAccess = { app.storageAnalyzer.openUsageAccessSettings() },
                                        onRequestAllFilesAccess = { app.storageAnalyzer.openAllFilesAccessSettings() },
                                        onRefreshOverview = {
                                            scope.launch {
                                                val (ov, list) = app.storageAnalyzer.analyzeOverviewAndApps()
                                                storageOverview = ov
                                                appStorageList = list
                                            }
                                        },
                                        onRunDeepScan = {
                                            scope.launch {
                                                isScanningStorage = true
                                                deepScanResult = app.storageAnalyzer.scanDeepStorage()
                                                isScanningStorage = false
                                            }
                                        },
                                        onCleanAllCaches = {
                                            scope.launch {
                                                isCleaningCaches = true
                                                app.storageAnalyzer.cleanAllCaches()
                                                val (ov, list) = app.storageAnalyzer.analyzeOverviewAndApps()
                                                storageOverview = ov
                                                appStorageList = list
                                                storageBannerMsg = strings.cachesCleanedResult
                                                isCleaningCaches = false
                                            }
                                        },
                                        onClearSingleAppCache = { pkg ->
                                            scope.launch {
                                                app.storageAnalyzer.clearSingleAppCache(pkg)
                                                val (ov, list) = app.storageAnalyzer.analyzeOverviewAndApps()
                                                storageOverview = ov
                                                appStorageList = list
                                            }
                                        },
                                        onOpenAppInfo = { pkg -> app.appRepository.openAppInfo(pkg) },
                                        onDeleteFiles = { paths ->
                                            scope.launch {
                                                app.storageAnalyzer.deleteFiles(paths)
                                                deepScanResult = app.storageAnalyzer.scanDeepStorage()
                                                val (ov, list) = app.storageAnalyzer.analyzeOverviewAndApps()
                                                storageOverview = ov
                                                appStorageList = list
                                            }
                                        },
                                        onDeleteEmptyFolders = { paths ->
                                            scope.launch {
                                                app.storageAnalyzer.deleteEmptyFolders(paths)
                                                deepScanResult = app.storageAnalyzer.scanDeepStorage()
                                            }
                                        }
                                    )
                                }
                            }

                            FlowTab.SETTINGS -> {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(MaterialTheme.colorScheme.background)
                                        .statusBarsPadding()
                                        .navigationBarsPadding()
                                ) {
                                    FlowSettingsScreen(
                                        settings = settings,
                                        isDefaultLauncher = isDefaultLauncher,
                                        hasOverlayPermission = hasOverlayPerm,
                                        onSetDefaultLauncher = { app.appRepository.openDefaultLauncherChooser() },
                                        onSelectLanguage = { lang ->
                                            scope.launch { app.preferences.setLanguage(lang) }
                                        },
                                        onSelectTheme = { mode ->
                                            scope.launch { app.preferences.setThemeMode(mode) }
                                        },
                                        onToggleEdgeSwitcher = { enable ->
                                            if (enable && !Settings.canDrawOverlays(this@MainActivity)) {
                                                val intent = Intent(
                                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                                    Uri.parse("package:$packageName")
                                                )
                                                startActivity(intent)
                                            } else {
                                                scope.launch { app.preferences.setEdgeSwitcherEnabled(enable) }
                                                if (enable) QuickSwitcherOverlayService.start(this@MainActivity)
                                                else QuickSwitcherOverlayService.stop(this@MainActivity)
                                            }
                                        },
                                        onSetAnimationSpeed = { speed ->
                                            scope.launch { app.preferences.setAnimationMultiplier(speed) }
                                        },
                                        onToggleAppLabels = { show ->
                                            scope.launch { app.preferences.setShowAppLabels(show) }
                                        }
                                    )
                                }
                            }
                        }

                        // Floating Glassy Hub Navigation Bar when inside Fixer / Storage / Settings
                        if (currentTab != FlowTab.LAUNCHER) {
                            FloatingHubNavBar(
                                currentTab = currentTab,
                                onSelectTab = { currentTab = it },
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .navigationBarsPadding()
                                    .padding(horizontal = 16.dp, vertical = 12.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.action == QuickSwitcherOverlayService.ACTION_OPEN_SWITCHER) {
            openSwitcherSignal = true
        }
    }
}

@Composable
private fun FloatingHubNavBar(
    currentTab: FlowTab,
    onSelectTab: (FlowTab) -> Unit,
    modifier: Modifier = Modifier
) {
    val s = LocalStrings.current
    val palette = LocalGlassPalette.current
    val shape = RoundedCornerShape(28.dp)

    Row(
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(palette.glassSurfaceElevated)
            .border(1.dp, palette.glassBorder, shape)
            .padding(horizontal = 8.dp, vertical = 8.dp)
    ) {
        NavPillItem(
            icon = Icons.Rounded.Home,
            label = s.homeTab,
            selected = currentTab == FlowTab.LAUNCHER,
            onClick = { onSelectTab(FlowTab.LAUNCHER) }
        )
        NavPillItem(
            icon = Icons.Rounded.HealthAndSafety,
            label = s.fixerTab,
            selected = currentTab == FlowTab.SYSTEM_FIX,
            onClick = { onSelectTab(FlowTab.SYSTEM_FIX) }
        )
        NavPillItem(
            icon = Icons.Rounded.Storage,
            label = s.storageTab,
            selected = currentTab == FlowTab.STORAGE,
            onClick = { onSelectTab(FlowTab.STORAGE) }
        )
        NavPillItem(
            icon = Icons.Rounded.Settings,
            label = s.settingsTab,
            selected = currentTab == FlowTab.SETTINGS,
            onClick = { onSelectTab(FlowTab.SETTINGS) }
        )
    }
}

@Composable
private fun NavPillItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val palette = LocalGlassPalette.current
    val color = if (selected) palette.accentBlue else palette.subtleText
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(18.dp))
            .background(if (selected) palette.accentBlue.copy(alpha = 0.14f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        Icon(icon, contentDescription = label, tint = color, modifier = Modifier.size(20.dp))
        Text(
            text = label,
            color = color,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
        )
    }
}
