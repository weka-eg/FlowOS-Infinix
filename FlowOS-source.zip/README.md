# FlowOS — Infinix Hot 50 (XOS) Launcher, System UI Fixer & Storage Analyzer

**FlowOS** is a native Android (**Kotlin + Jetpack Compose**) application designed for **Infinix** phones (especially **Infinix Hot 50 / XOS 14**, Android 12–15).

## Core Features

1. **iOS-Style 120Hz Launcher & Quick Switcher**
   - Home grid, frosted glass Dock (pin/unpin up to 4 apps), categorized **App Library**, and instant search.
   - 120Hz spring physics (`FlowSprings`) coupled with `ActivityOptions.makeScaleUpAnimation`.
   - **Quick App Switcher** card deck + optional **Floating Edge Quick Switcher** overlay (`QuickSwitcherOverlayService`) for fast app switching without relying on laggy system Recents.

2. **System UI Repair Engine (`SystemUiFixer`)**
   - Live RAM & `com.android.systemui` memory diagnostics.
   - **One-Tap Smart Fix** (via **Shizuku**, no root required): trims system/app caches (`pm trim-caches`), tunes animation scales to `0.75x`, enables `cached_apps_freezer`, and compacts idle background processes.
   - Safe, reversible **XOS Services / Bloatware Manager** (`pm disable-user` / `pm enable` for Transsion packages like `com.transsion.smartpanel`, `com.transsion.palmstore`, etc.).
   - Clean `System UI` restart trigger & Infinix Hot 50 **MemFusion** advisory.

3. **iOS-Style Storage & Cache Analyzer (`StorageAnalyzer`)**
   - Segmented storage breakdown bar (Apps, Caches, Media & Files, System/Other, Free).
   - Per-app cache/data breakdown via `StorageStatsManager` + one-tap cache trimming via Shizuku.
   - Deep scanner for **Large Files (≥ 25 MB)**, **WhatsApp & Telegram media**, **Forgotten APKs**, **Duplicate Files** (fast size + partial SHA-256 hash), and **Empty Folders**.

4. **Bilingual UI (Arabic RTL & English LTR)**
   - Instant language switching + Dark / Light / System glassmorphism themes.

## Building the APK

1. Open `C:\Users\mosta\.gemini\antigravity\scratch\FlowOS` in **Android Studio** (Ladybug or newer) with **JDK 17** and **Android SDK 35**.
2. Let Gradle sync download dependencies (`dev.rikka.shizuku:api`, `Compose BOM`, `HiddenApiBypass`).
3. Connect your **Infinix Hot 50** via USB Debugging or build **Build > Build APK(s)** (`app-debug.apk` or signed release).

## Setting Up Shizuku on Infinix Hot 50 (No Root)

1. Open **Settings > My Phone** and tap **Build Number** 7 times.
2. Go to **System > Developer Options** and enable **USB Debugging** and **Wireless Debugging**.
3. Install the official **Shizuku** app, pair via Wireless Debugging, and tap **Start**.
4. Open **FlowOS > System Fix**, tap **Grant Access**, and enjoy full cache trimming & System UI repair.
