package com.flowos.infinix.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.TipsAndUpdates
import androidx.compose.material.icons.rounded.ViewCarousel
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.flowos.infinix.core.i18n.LocalStrings
import com.flowos.infinix.core.prefs.AppLanguage
import com.flowos.infinix.core.prefs.AppThemeMode
import com.flowos.infinix.core.prefs.FlowSettingsState
import com.flowos.infinix.core.theme.LocalGlassPalette
import com.flowos.infinix.ui.components.GlassCard
import com.flowos.infinix.ui.components.StatusPill
import java.util.Locale

@Composable
fun FlowSettingsScreen(
    settings: FlowSettingsState,
    isDefaultLauncher: Boolean,
    hasOverlayPermission: Boolean,
    onSetDefaultLauncher: () -> Unit,
    onSelectLanguage: (AppLanguage) -> Unit,
    onSelectTheme: (AppThemeMode) -> Unit,
    onToggleEdgeSwitcher: (Boolean) -> Unit,
    onSetAnimationSpeed: (Float) -> Unit,
    onToggleAppLabels: (Boolean) -> Unit
) {
    val s = LocalStrings.current
    val palette = LocalGlassPalette.current

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Text(
                text = s.settingsTitle,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
        }

        // Default Launcher Card
        item {
            GlassCard(elevated = true, modifier = Modifier.fillMaxWidth()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Home, contentDescription = null, tint = palette.accentBlue)
                        Spacer(Modifier.width(8.dp))
                        Text(s.defaultLauncherTitle, style = MaterialTheme.typography.titleMedium)
                    }
                    StatusPill(
                        text = if (isDefaultLauncher) s.active else "XOS",
                        color = if (isDefaultLauncher) palette.successGreen else palette.warningAmber
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    text = s.defaultLauncherDesc,
                    style = MaterialTheme.typography.bodyMedium,
                    color = palette.subtleText
                )
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = onSetDefaultLauncher,
                    colors = ButtonDefaults.buttonColors(containerColor = palette.accentBlue),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(s.setDefaultLauncherBtn)
                }
            }
        }

        // Language Toggle
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Language, contentDescription = null, tint = palette.accentCyan)
                    Spacer(Modifier.width(8.dp))
                    Text(s.languageTitle, style = MaterialTheme.typography.titleMedium)
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    FilterChip(
                        selected = settings.language == AppLanguage.AR,
                        onClick = { onSelectLanguage(AppLanguage.AR) },
                        label = { Text("العربية (RTL)") },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = settings.language == AppLanguage.EN,
                        onClick = { onSelectLanguage(AppLanguage.EN) },
                        label = { Text("English (LTR)") },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Theme Mode
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Palette, contentDescription = null, tint = palette.accentBlue)
                    Spacer(Modifier.width(8.dp))
                    Text(s.themeTitle, style = MaterialTheme.typography.titleMedium)
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    FilterChip(
                        selected = settings.themeMode == AppThemeMode.SYSTEM,
                        onClick = { onSelectTheme(AppThemeMode.SYSTEM) },
                        label = { Text(s.themeSystem) },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = settings.themeMode == AppThemeMode.DARK,
                        onClick = { onSelectTheme(AppThemeMode.DARK) },
                        label = { Text(s.themeDark) },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = settings.themeMode == AppThemeMode.LIGHT,
                        onClick = { onSelectTheme(AppThemeMode.LIGHT) },
                        label = { Text(s.themeLight) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Edge Quick Switcher & Launcher Motion
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Rounded.ViewCarousel, contentDescription = null, tint = palette.accentCyan)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(s.edgeSwitcherTitle, style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = if (hasOverlayPermission) s.edgeSwitcherDesc else "${s.edgeSwitcherDesc} (Overlay)",
                                style = MaterialTheme.typography.labelMedium,
                                color = palette.subtleText
                            )
                        }
                    }
                    Spacer(Modifier.width(8.dp))
                    Switch(
                        checked = settings.edgeSwitcherEnabled && hasOverlayPermission,
                        onCheckedChange = onToggleEdgeSwitcher
                    )
                }

                Spacer(Modifier.height(14.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(s.showAppLabelsTitle, style = MaterialTheme.typography.bodyMedium)
                    Switch(
                        checked = settings.showAppLabels,
                        onCheckedChange = onToggleAppLabels
                    )
                }

                Spacer(Modifier.height(14.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Speed, contentDescription = null, tint = palette.successGreen)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "${s.launcherMotionTitle}: ${String.format(Locale.US, "%.2fx", settings.animationSpeedMultiplier)}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium
                    )
                }
                Slider(
                    value = settings.animationSpeedMultiplier,
                    onValueChange = onSetAnimationSpeed,
                    valueRange = 0.6f..1.4f
                )
            }
        }

        // Infinix Hot 50 Optimization Tips
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.TipsAndUpdates, contentDescription = null, tint = palette.warningAmber)
                    Spacer(Modifier.width(8.dp))
                    Text(s.hot50TipsTitle, style = MaterialTheme.typography.titleMedium)
                }
                Spacer(Modifier.height(8.dp))
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    s.hot50Tips.forEach { tip ->
                        Text(tip, style = MaterialTheme.typography.bodyMedium, color = palette.subtleText)
                    }
                }
            }
        }
    }
}
