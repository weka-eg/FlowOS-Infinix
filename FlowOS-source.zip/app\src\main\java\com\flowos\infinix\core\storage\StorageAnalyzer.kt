package com.flowos.infinix.core.storage

import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import android.os.Process
import android.os.StatFs
import android.os.storage.StorageManager
import android.provider.Settings
import com.flowos.infinix.core.shizuku.ShizukuBridge
import com.flowos.infinix.core.shizuku.ShizukuStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile
import java.security.MessageDigest

data class StorageOverview(
    val totalBytes: Long,
    val freeBytes: Long,
    val usedBytes: Long,
    val appsBytes: Long,
    val totalCachesBytes: Long,
    val mediaFilesBytes: Long,
    val systemOtherBytes: Long
)

data class AppStorageItem(
    val packageName: String,
    val label: String,
    val appBytes: Long,
    val dataBytes: Long,
    val cacheBytes: Long
) {
    val totalBytes: Long get() = appBytes + dataBytes + cacheBytes
}

data class ScannedFileItem(
    val path: String,
    val name: String,
    val sizeBytes: Long,
    val lastModified: Long,
    val category: FileScanCategory
)

enum class FileScanCategory {
    LARGE_FILE,
    WHATSAPP_TELEGRAM,
    APK,
    DUPLICATE
}

data class DuplicateGroup(
    val hash: String,
    val sizeBytes: Long,
    val files: List<ScannedFileItem>
)

data class DeepStorageScanResult(
    val largeFiles: List<ScannedFileItem>,
    val messagingFiles: List<ScannedFileItem>,
    val apkFiles: List<ScannedFileItem>,
    val duplicateGroups: List<DuplicateGroup>,
    val emptyFolders: List<String>
)

class StorageAnalyzer(
    private val context: Context,
    private val shizuku: ShizukuBridge
) {

    fun hasUsageAccess(): Boolean {
        val appOps = context.getSystemService(AppOpsManager::class.java) ?: return false
        val mode = appOps.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            context.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun hasAllFilesAccess(): Boolean = Environment.isExternalStorageManager()

    fun openUsageAccessSettings() {
        val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { context.startActivity(intent) }
    }

    fun openAllFilesAccessSettings() {
        val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
            data = Uri.fromParts("package", context.packageName, null)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { context.startActivity(intent) }.onFailure {
            val fallback = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            runCatching { context.startActivity(fallback) }
        }
    }

    suspend fun analyzeOverviewAndApps(): Pair<StorageOverview, List<AppStorageItem>> =
        withContext(Dispatchers.IO) {
            val stat = StatFs(Environment.getDataDirectory().path)
            val totalBytes = stat.totalBytes
            val freeBytes = stat.availableBytes
            val usedBytes = (totalBytes - freeBytes).coerceAtLeast(0L)

            val appItems = mutableListOf<AppStorageItem>()
            var totalAppOnlyBytes = 0L
            var totalCacheBytes = 0L

            if (hasUsageAccess()) {
                val statsManager = context.getSystemService(StorageStatsManager::class.java)
                val pm = context.packageManager
                val packages = pm.getInstalledApplications(PackageManager.MATCH_ALL)
                val uuid = StorageManager.UUID_DEFAULT
                val userHandle = Process.myUserHandle()

                for (app in packages) {
                    runCatching {
                        val s = statsManager.queryStatsForPackage(uuid, app.packageName, userHandle)
                        val item = AppStorageItem(
                            packageName = app.packageName,
                            label = pm.getApplicationLabel(app).toString(),
                            appBytes = s.appBytes,
                            dataBytes = s.dataBytes,
                            cacheBytes = s.cacheBytes
                        )
                        if (item.totalBytes > 0) {
                            appItems.add(item)
                            totalAppOnlyBytes += s.appBytes + s.dataBytes
                            totalCacheBytes += s.cacheBytes
                        }
                    }
                }
            }

            var mediaBytes = 0L
            if (hasAllFilesAccess()) {
                val extRoot = Environment.getExternalStorageDirectory()
                mediaBytes = estimateMediaDirectorySize(extRoot)
            }

            val accounted = totalAppOnlyBytes + totalCacheBytes + mediaBytes
            val systemOther = (usedBytes - accounted).coerceAtLeast(0L)

            val overview = StorageOverview(
                totalBytes = totalBytes,
                freeBytes = freeBytes,
                usedBytes = usedBytes,
                appsBytes = totalAppOnlyBytes,
                totalCachesBytes = totalCacheBytes,
                mediaFilesBytes = mediaBytes,
                systemOtherBytes = systemOther
            )

            Pair(overview, appItems.sortedByDescending { it.cacheBytes })
        }

    suspend fun scanDeepStorage(): DeepStorageScanResult = withContext(Dispatchers.IO) {
        if (!hasAllFilesAccess()) {
            return@withContext DeepStorageScanResult(
                largeFiles = emptyList(),
                messagingFiles = emptyList(),
                apkFiles = emptyList(),
                duplicateGroups = emptyList(),
                emptyFolders = emptyList()
            )
        }

        val root = Environment.getExternalStorageDirectory()
        val largeThreshold = 25L * 1024L * 1024L // 25 MB
        val dupeMinSize = 64L * 1024L // 64 KB

        val largeFiles = mutableListOf<ScannedFileItem>()
        val messagingFiles = mutableListOf<ScannedFileItem>()
        val apkFiles = mutableListOf<ScannedFileItem>()
        val emptyFolders = mutableListOf<String>()
        val sizeBuckets = HashMap<Long, MutableList<File>>()

        val queue = ArrayDeque<File>()
        queue.add(root)

        while (queue.isNotEmpty()) {
            val dir = queue.removeFirst()
            val children = dir.listFiles() ?: continue
            if (children.isEmpty() && dir != root && !dir.name.startsWith(".")) {
                emptyFolders.add(dir.absolutePath)
                continue
            }

            for (child in children) {
                if (child.isDirectory) {
                    // Skip protected Android/obb & Android/data root unless accessible
                    val rel = child.absolutePath
                    if (!rel.endsWith("/Android/obb") && !child.name.equals(".thumbnails", ignoreCase = true)) {
                        queue.add(child)
                    }
                } else if (child.isFile) {
                    val size = child.length()
                    if (size <= 0L) continue
                    val path = child.absolutePath
                    val lowerPath = path.lowercase()

                    if (size >= largeThreshold) {
                        largeFiles.add(
                            ScannedFileItem(path, child.name, size, child.lastModified(), FileScanCategory.LARGE_FILE)
                        )
                    }

                    if (lowerPath.endsWith(".apk")) {
                        apkFiles.add(
                            ScannedFileItem(path, child.name, size, child.lastModified(), FileScanCategory.APK)
                        )
                    }

                    if (isMessagingMediaPath(lowerPath) && size >= 512L * 1024L) {
                        messagingFiles.add(
                            ScannedFileItem(path, child.name, size, child.lastModified(), FileScanCategory.WHATSAPP_TELEGRAM)
                        )
                    }

                    if (size >= dupeMinSize && !lowerPath.contains("/android/data/")) {
                        sizeBuckets.getOrPut(size) { mutableListOf() }.add(child)
                    }
                }
            }
        }

        // Fast duplicate detection: only hash files sharing exact byte length
        val duplicateGroups = mutableListOf<DuplicateGroup>()
        for ((size, candidates) in sizeBuckets) {
            if (candidates.size < 2) continue
            val byHash = HashMap<String, MutableList<ScannedFileItem>>()
            for (file in candidates) {
                val hash = fastPartialHash(file) ?: continue
                byHash.getOrPut(hash) { mutableListOf() }.add(
                    ScannedFileItem(
                        path = file.absolutePath,
                        name = file.name,
                        sizeBytes = size,
                        lastModified = file.lastModified(),
                        category = FileScanCategory.DUPLICATE
                    )
                )
            }
            for ((hash, group) in byHash) {
                if (group.size >= 2) {
                    duplicateGroups.add(DuplicateGroup(hash, size, group.sortedBy { it.lastModified }))
                }
            }
        }

        DeepStorageScanResult(
            largeFiles = largeFiles.sortedByDescending { it.sizeBytes }.take(120),
            messagingFiles = messagingFiles.sortedByDescending { it.sizeBytes }.take(120),
            apkFiles = apkFiles.sortedByDescending { it.sizeBytes },
            duplicateGroups = duplicateGroups.sortedByDescending { it.sizeBytes * (it.files.size - 1) }.take(60),
            emptyFolders = emptyFolders.take(200)
        )
    }

    suspend fun cleanAllCaches(): Boolean = withContext(Dispatchers.IO) {
        var cleaned = false
        if (shizuku.status.value == ShizukuStatus.READY) {
            val res = shizuku.runShell("pm trim-caches 1024G")
            // Also trim accessible external app cache directories
            shizuku.runShell("find /sdcard/Android/data -maxdepth 3 -type d -name cache -exec rm -rf {}/* \\; 2>/dev/null")
            cleaned = res.success
        }
        // Always clean FlowOS's own internal cache too
        runCatching { context.cacheDir.deleteRecursively() }
        cleaned
    }

    suspend fun clearSingleAppCache(packageName: String): Boolean = withContext(Dispatchers.IO) {
        if (shizuku.status.value != ShizukuStatus.READY) return@withContext false
        val safePkg = packageName.replace(Regex("[^a-zA-Z0-9._]"), "")
        val res = shizuku.runShell(
            "rm -rf /sdcard/Android/data/$safePkg/cache/* 2>/dev/null; pm trim-caches 512M"
        )
        res.success
    }

    suspend fun deleteFiles(paths: Collection<String>): Int = withContext(Dispatchers.IO) {
        var deletedCount = 0
        val deletedPaths = mutableListOf<String>()
        for (path in paths) {
            val file = File(path)
            if (file.exists() && file.delete()) {
                deletedCount++
                deletedPaths.add(path)
            }
        }
        if (deletedPaths.isNotEmpty()) {
            MediaScannerConnection.scanFile(context, deletedPaths.toTypedArray(), null, null)
        }
        deletedCount
    }

    suspend fun deleteEmptyFolders(paths: Collection<String>): Int = withContext(Dispatchers.IO) {
        var removed = 0
        for (path in paths.sortedByDescending { it.length }) {
            val dir = File(path)
            if (dir.isDirectory && (dir.list()?.isEmpty() == true) && dir.delete()) {
                removed++
            }
        }
        removed
    }

    private fun isMessagingMediaPath(lowerPath: String): Boolean {
        return lowerPath.contains("/whatsapp/") ||
            lowerPath.contains("/com.whatsapp/") ||
            lowerPath.contains("/telegram/") ||
            lowerPath.contains("/org.telegram.messenger/")
    }

    private fun estimateMediaDirectorySize(root: File): Long {
        val mediaDirs = listOf("DCIM", "Pictures", "Movies", "Music", "Download", "Documents")
        var total = 0L
        for (name in mediaDirs) {
            val dir = File(root, name)
            if (dir.exists()) {
                total += sumDirLimited(dir, depth = 0)
            }
        }
        return total
    }

    private fun sumDirLimited(dir: File, depth: Int): Long {
        if (depth > 5) return 0L
        val files = dir.listFiles() ?: return 0L
        var sum = 0L
        for (f in files) {
            sum += if (f.isFile) f.length() else sumDirLimited(f, depth + 1)
        }
        return sum
    }

    private fun fastPartialHash(file: File): String? {
        return runCatching {
            val digest = MessageDigest.getInstance("SHA-256")
            val len = file.length()
            val chunkSize = 16 * 1024
            val buffer = ByteArray(chunkSize)

            RandomAccessFile(file, "r").use { raf ->
                val readHead = raf.read(buffer)
                if (readHead > 0) digest.update(buffer, 0, readHead)

                if (len > chunkSize * 2) {
                    raf.seek(len / 2)
                    val readMid = raf.read(buffer)
                    if (readMid > 0) digest.update(buffer, 0, readMid)
                }

                if (len > chunkSize) {
                    raf.seek((len - chunkSize).coerceAtLeast(0L))
                    val readTail = raf.read(buffer)
                    if (readTail > 0) digest.update(buffer, 0, readTail)
                }
            }

            digest.digest().joinToString("") { "%02x".format(it) }
        }.getOrNull()
    }
}
