package com.flowos.infinix.ui.storage

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.FolderDelete
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.flowos.infinix.core.i18n.LocalStrings
import com.flowos.infinix.core.shizuku.ShizukuStatus
import com.flowos.infinix.core.storage.AppStorageItem
import com.flowos.infinix.core.storage.DeepStorageScanResult
import com.flowos.infinix.core.storage.ScannedFileItem
import com.flowos.infinix.core.storage.StorageOverview
import com.flowos.infinix.core.theme.LocalGlassPalette
import com.flowos.infinix.ui.components.GlassCard
import com.flowos.infinix.ui.components.formatBytes

@Composable
fun StorageAnalyzerScreen(
    overview: StorageOverview?,
    appStorageList: List<AppStorageItem>,
    deepScanResult: DeepStorageScanResult?,
    hasUsageAccess: Boolean,
    hasAllFilesAccess: Boolean,
    shizukuStatus: ShizukuStatus,
    isScanning: Boolean,
    isCleaningCaches: Boolean,
    statusBannerMessage: String?,
    onRequestUsageAccess: () -> Unit,
    onRequestAllFilesAccess: () -> Unit,
    onRefreshOverview: () -> Unit,
    onRunDeepScan: () -> Unit,
    onCleanAllCaches: () -> Unit,
    onClearSingleAppCache: (String) -> Unit,
    onOpenAppInfo: (String) -> Unit,
    onDeleteFiles: (List<String>) -> Unit,
    onDeleteEmptyFolders: (List<String>) -> Unit
) {
    val s = LocalStrings.current
    val palette = LocalGlassPalette.current

    var selectedTab by remember { mutableIntStateOf(0) }
    val selectedPaths = remember { mutableStateListOf<String>() }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    val shizukuReady = shizukuStatus == ShizukuStatus.READY

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = s.storageTitle,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onRefreshOverview) {
                        Icon(Icons.Rounded.Refresh, contentDescription = s.refresh)
                    }
                }
            }

            // iOS-style Segmented Storage Overview Card
            if (overview != null) {
                item {
                    IosStorageBarCard(overview = overview)
                }
            }

            // Permissions card if missing
            if (!hasUsageAccess || !hasAllFilesAccess) {
                item {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = s.storagePermissionTitle,
                            style = MaterialTheme.typography.titleMedium,
                            color = palette.warningAmber
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = s.storagePermissionDesc,
                            style = MaterialTheme.typography.bodyMedium,
                            color = palette.subtleText
                        )
                        Spacer(Modifier.height(10.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (!hasUsageAccess) {
                                Button(
                                    onClick = onRequestUsageAccess,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(s.grantUsagePermission, maxLines = 1)
                                }
                            }
                            if (!hasAllFilesAccess) {
                                OutlinedButton(
                                    onClick = onRequestAllFilesAccess,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(s.grantFilesPermission, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }

            // Primary Action Row: Clean All Caches + Deep Scan
            item {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Button(
                        onClick = onCleanAllCaches,
                        enabled = !isCleaningCaches,
                        colors = ButtonDefaults.buttonColors(containerColor = palette.accentBlue),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        if (isCleaningCaches) {
                            CircularProgressIndicator(
                                color = Color.White,
                                strokeWidth = 2.dp,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(s.cleaningCaches, maxLines = 1)
                        } else {
                            Icon(Icons.Rounded.CleaningServices, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(s.cleanAllCaches, maxLines = 1)
                        }
                    }

                    OutlinedButton(
                        onClick = onRunDeepScan,
                        enabled = !isScanning && hasAllFilesAccess,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        if (isScanning) {
                            CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(s.scanningStorage, maxLines = 1)
                        } else {
                            Icon(Icons.Rounded.Search, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(s.scanStorageBtn, maxLines = 1)
                        }
                    }
                }
            }

            if (statusBannerMessage != null) {
                item {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = statusBannerMessage,
                            color = palette.successGreen,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Sub-navigation tabs
            item {
                val tabs = listOf(s.tabAppsCache, s.tabLargeFiles, s.tabMessaging, s.tabApksDupes)
                ScrollableTabRow(
                    selectedTabIndex = selectedTab,
                    edgePadding = 0.dp,
                    containerColor = Color.Transparent,
                    divider = {}
                ) {
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = { Text(title, fontWeight = FontWeight.SemiBold) }
                        )
                    }
                }
            }

            when (selectedTab) {
                0 -> {
                    if (appStorageList.isEmpty()) {
                        item {
                            GlassCard(modifier = Modifier.fillMaxWidth()) {
                                Text(s.noItemsFound, color = palette.subtleText)
                            }
                        }
                    } else {
                        items(appStorageList, key = { it.packageName }) { app ->
                            AppStorageRow(
                                item = app,
                                shizukuReady = shizukuReady,
                                onClearCache = { onClearSingleAppCache(app.packageName) },
                                onOpenInfo = { onOpenAppInfo(app.packageName) }
                            )
                        }
                    }
                }

                1 -> {
                    val files = deepScanResult?.largeFiles.orEmpty()
                    if (files.isEmpty()) {
                        item { EmptyScanPrompt(onRunDeepScan = onRunDeepScan, hasAccess = hasAllFilesAccess) }
                    } else {
                        items(files, key = { it.path }) { file ->
                            SelectableFileRow(
                                item = file,
                                checked = selectedPaths.contains(file.path),
                                onToggle = {
                                    if (selectedPaths.contains(file.path)) selectedPaths.remove(file.path)
                                    else selectedPaths.add(file.path)
                                }
                            )
                        }
                    }
                }

                2 -> {
                    val files = deepScanResult?.messagingFiles.orEmpty()
                    if (files.isEmpty()) {
                        item { EmptyScanPrompt(onRunDeepScan = onRunDeepScan, hasAccess = hasAllFilesAccess) }
                    } else {
                        items(files, key = { it.path }) { file ->
                            SelectableFileRow(
                                item = file,
                                checked = selectedPaths.contains(file.path),
                                onToggle = {
                                    if (selectedPaths.contains(file.path)) selectedPaths.remove(file.path)
                                    else selectedPaths.add(file.path)
                                }
                            )
                        }
                    }
                }

                3 -> {
                    val apks = deepScanResult?.apkFiles.orEmpty()
                    val dupes = deepScanResult?.duplicateGroups.orEmpty()
                    val emptyFolders = deepScanResult?.emptyFolders.orEmpty()

                    if (apks.isEmpty() && dupes.isEmpty() && emptyFolders.isEmpty()) {
                        item { EmptyScanPrompt(onRunDeepScan = onRunDeepScan, hasAccess = hasAllFilesAccess) }
                    } else {
                        if (emptyFolders.isNotEmpty()) {
                            item {
                                GlassCard(modifier = Modifier.fillMaxWidth()) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Rounded.FolderDelete, contentDescription = null, tint = palette.warningAmber)
                                            Spacer(Modifier.width(8.dp))
                                            Text(
                                                "${s.emptyFoldersSection} (${emptyFolders.size})",
                                                style = MaterialTheme.typography.titleMedium
                                            )
                                        }
                                        TextButton(onClick = { onDeleteEmptyFolders(emptyFolders) }) {
                                            Text(s.cleanEmptyFolders)
                                        }
                                    }
                                }
                            }
                        }

                        if (apks.isNotEmpty()) {
                            item {
                                Text(
                                    text = "${s.apksSection} (${apks.size})",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            items(apks, key = { it.path }) { apk ->
                                SelectableFileRow(
                                    item = apk,
                                    checked = selectedPaths.contains(apk.path),
                                    onToggle = {
                                        if (selectedPaths.contains(apk.path)) selectedPaths.remove(apk.path)
                                        else selectedPaths.add(apk.path)
                                    }
                                )
                            }
                        }

                        if (dupes.isNotEmpty()) {
                            item {
                                Text(
                                    text = "${s.duplicatesSection} (${dupes.size})",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(top = 6.dp)
                                )
                            }
                            items(dupes, key = { it.hash }) { group ->
                                GlassCard(modifier = Modifier.fillMaxWidth()) {
                                    Text(
                                        text = "${group.files.firstOrNull()?.name ?: "File"} • ${formatBytes(group.sizeBytes)} × ${group.files.size}",
                                        style = MaterialTheme.typography.titleMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(Modifier.height(6.dp))
                                    group.files.forEach { dupeFile ->
                                        val isChecked = selectedPaths.contains(dupeFile.path)
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable {
                                                    if (isChecked) selectedPaths.remove(dupeFile.path)
                                                    else selectedPaths.add(dupeFile.path)
                                                }
                                                .padding(vertical = 2.dp)
                                        ) {
                                            Checkbox(
                                                checked = isChecked,
                                                onCheckedChange = { checked ->
                                                    if (checked) selectedPaths.add(dupeFile.path)
                                                    else selectedPaths.remove(dupeFile.path)
                                                }
                                            )
                                            Text(
                                                text = dupeFile.path,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = palette.subtleText,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Floating Delete Action Bar when files are selected
        if (selectedPaths.isNotEmpty()) {
            GlassCard(
                elevated = true,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, bottom = 92.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${s.deleteSelectedCount} (${selectedPaths.size})",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Button(
                        onClick = { showDeleteConfirm = true },
                        colors = ButtonDefaults.buttonColors(containerColor = palette.dangerRed)
                    ) {
                        Icon(Icons.Rounded.Delete, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text(s.delete)
                    }
                }
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text(s.deleteConfirmTitle) },
            text = { Text(s.deleteConfirmBody) },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        val toDelete = selectedPaths.toList()
                        selectedPaths.clear()
                        onDeleteFiles(toDelete)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = palette.dangerRed)
                ) {
                    Text(s.delete)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text(s.cancel)
                }
            }
        )
    }
}

@Composable
private fun IosStorageBarCard(overview: StorageOverview) {
    val s = LocalStrings.current
    val palette = LocalGlassPalette.current
    val total = overview.totalBytes.coerceAtLeast(1L).toFloat()

    val appsColor = Color(0xFF38BDF8)
    val cacheColor = Color(0xFFFBBF24)
    val mediaColor = Color(0xFF34D399)
    val otherColor = Color(0xFF94A3B8)

    val appsWeight = (overview.appsBytes / total).coerceAtLeast(0.02f)
    val cacheWeight = (overview.totalCachesBytes / total).coerceAtLeast(0.01f)
    val mediaWeight = (overview.mediaFilesBytes / total).coerceAtLeast(0.02f)
    val otherWeight = (overview.systemOtherBytes / total).coerceAtLeast(0.02f)
    val freeWeight = (overview.freeBytes / total).coerceAtLeast(0.02f)

    GlassCard(elevated = true, modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            Text(
                text = "${formatBytes(overview.usedBytes)} ${s.storageUsedOf} ${formatBytes(overview.totalBytes)}",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "${formatBytes(overview.freeBytes)} ${s.catFree}",
                style = MaterialTheme.typography.labelMedium,
                color = palette.successGreen,
                fontWeight = FontWeight.SemiBold
            )
        }

        Spacer(Modifier.height(12.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(16.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Box(Modifier.weight(appsWeight).fillMaxHeight().background(appsColor))
            Box(Modifier.weight(cacheWeight).fillMaxHeight().background(cacheColor))
            Box(Modifier.weight(mediaWeight).fillMaxHeight().background(mediaColor))
            Box(Modifier.weight(otherWeight).fillMaxHeight().background(otherColor))
            Box(Modifier.weight(freeWeight).fillMaxHeight().background(Color.Transparent))
        }

        Spacer(Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            LegendDot(s.catApps, formatBytes(overview.appsBytes), appsColor)
            LegendDot(s.cacheLabel, formatBytes(overview.totalCachesBytes), cacheColor)
            LegendDot(s.catMediaFiles, formatBytes(overview.mediaFilesBytes), mediaColor)
            LegendDot(s.catSystemOther, formatBytes(overview.systemOtherBytes), otherColor)
        }
    }
}

@Composable
private fun LegendDot(label: String, sizeText: String, color: Color) {
    Column(horizontalAlignment = Alignment.Start) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(color))
            Spacer(Modifier.width(4.dp))
            Text(label, style = MaterialTheme.typography.labelSmall)
        }
        Text(sizeText, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun AppStorageRow(
    item: AppStorageItem,
    shizukuReady: Boolean,
    onClearCache: () -> Unit,
    onOpenInfo: () -> Unit
) {
    val s = LocalStrings.current
    val palette = LocalGlassPalette.current

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.label,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(3.dp))
                Text(
                    text = "${s.cacheLabel}: ${formatBytes(item.cacheBytes)} • ${s.dataLabel}: ${formatBytes(item.dataBytes)} • ${s.appSizeLabel}: ${formatBytes(item.appBytes)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = palette.subtleText
                )
            }
            Spacer(Modifier.width(8.dp))
            if (shizukuReady && item.cacheBytes > 0L) {
                TextButton(onClick = onClearCache) {
                    Text(s.clearAppCache, color = palette.warningAmber)
                }
            } else {
                TextButton(onClick = onOpenInfo) {
                    Text(s.openSystemAppInfo)
                }
            }
        }
    }
}

@Composable
private fun SelectableFileRow(
    item: ScannedFileItem,
    checked: Boolean,
    onToggle: () -> Unit
) {
    val palette = LocalGlassPalette.current
    GlassCard(
        onClick = onToggle,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Checkbox(checked = checked, onCheckedChange = { onToggle() })
            Spacer(Modifier.width(6.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.name,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = item.path,
                    style = MaterialTheme.typography.labelSmall,
                    color = palette.subtleText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.width(8.dp))
            Text(
                text = formatBytes(item.sizeBytes),
                style = MaterialTheme.typography.labelMedium,
                color = palette.accentBlue,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun EmptyScanPrompt(onRunDeepScan: () -> Unit, hasAccess: Boolean) {
    val s = LocalStrings.current
    val palette = LocalGlassPalette.current
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text(s.noItemsFound, color = palette.subtleText)
        if (hasAccess) {
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onRunDeepScan) {
                Text(s.scanStorageBtn)
            }
        }
    }
}
