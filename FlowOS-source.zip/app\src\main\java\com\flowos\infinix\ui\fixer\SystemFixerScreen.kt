package com.flowos.infinix.ui.fixer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.StopCircle
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.flowos.infinix.core.i18n.LocalStrings
import com.flowos.infinix.core.shizuku.ShizukuStatus
import com.flowos.infinix.core.systemui.PackageFreezeRisk
import com.flowos.infinix.core.systemui.SmartFixReport
import com.flowos.infinix.core.systemui.SystemDiagnostics
import com.flowos.infinix.core.theme.LocalGlassPalette
import com.flowos.infinix.ui.components.GlassCard
import com.flowos.infinix.ui.components.ShizukuSetupDialog
import com.flowos.infinix.ui.components.ShizukuStatusCard
import com.flowos.infinix.ui.components.StatusPill

@Composable
fun SystemFixerScreen(
    isArabic: Boolean,
    shizukuStatus: ShizukuStatus,
    isShizukuInstalled: Boolean,
    diagnostics: SystemDiagnostics?,
    isFixing: Boolean,
    currentFixStep: String?,
    lastFixReport: SmartFixReport?,
    onRefreshDiagnostics: () -> Unit,
    onGrantShizuku: () -> Unit,
    onOpenShizukuApp: () -> Unit,
    onOpenDevOptions: () -> Unit,
    onRunSmartFix: () -> Unit,
    onRestartSystemUi: () -> Unit,
    onSetAnimationScale: (Float) -> Unit,
    onToggleXosPackage: (String, Boolean) -> Unit,
    onForceStopPackage: (String) -> Unit
) {
    val s = LocalStrings.current
    val palette = LocalGlassPalette.current
    var showShizukuGuide by remember { mutableStateOf(false) }
    var showRestartConfirm by remember { mutableStateOf(false) }

    val shizukuReady = shizukuStatus == ShizukuStatus.READY

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = s.systemFixerTitle,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = s.systemFixerSubtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = palette.subtleText
                    )
                }
                IconButton(onClick = onRefreshDiagnostics) {
                    Icon(Icons.Rounded.Refresh, contentDescription = s.refresh)
                }
            }
        }

        item {
            ShizukuStatusCard(
                status = shizukuStatus,
                onGrantClick = onGrantShizuku,
                onOpenGuide = { showShizukuGuide = true }
            )
        }

        // Device & RAM Health Card
        if (diagnostics != null) {
            item {
                val usedMb = (diagnostics.totalRamMb - diagnostics.availableRamMb).coerceAtLeast(0L)
                val usedRatio = if (diagnostics.totalRamMb > 0) {
                    (usedMb.toFloat() / diagnostics.totalRamMb.toFloat()).coerceIn(0f, 1f)
                } else 0f
                val ramColor = when {
                    diagnostics.isLowMemory || usedRatio > 0.85f -> palette.dangerRed
                    usedRatio > 0.70f -> palette.warningAmber
                    else -> palette.successGreen
                }

                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Memory, contentDescription = null, tint = ramColor)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = s.ramHealthLabel,
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                        StatusPill(
                            text = "${diagnostics.manufacturer} ${diagnostics.deviceModel}",
                            color = palette.accentBlue
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    LinearProgressIndicator(
                        progress = { usedRatio },
                        color = ramColor,
                        trackColor = ramColor.copy(alpha = 0.2f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(50))
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${diagnostics.availableRamMb} MB ${s.ramAvailableOf} ${diagnostics.totalRamMb} MB",
                            style = MaterialTheme.typography.labelMedium,
                            color = palette.subtleText
                        )
                        if (diagnostics.systemUiMemoryMb != null) {
                            Text(
                                text = "SystemUI: ${diagnostics.systemUiMemoryMb} MB",
                                style = MaterialTheme.typography.labelMedium,
                                color = palette.accentCyan,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        // Infinix MemFusion Advisory
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.Top) {
                    Icon(
                        Icons.Rounded.Warning,
                        contentDescription = null,
                        tint = palette.warningAmber,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(
                            text = s.memFusionWarningTitle,
                            style = MaterialTheme.typography.titleMedium,
                            color = palette.warningAmber
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = s.memFusionWarningDesc,
                            style = MaterialTheme.typography.bodyMedium,
                            color = palette.subtleText
                        )
                    }
                }
            }
        }

        // One-Tap Smart Fix & Restart SystemUI Actions
        item {
            GlassCard(elevated = true, modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = onRunSmartFix,
                    enabled = !isFixing,
                    colors = ButtonDefaults.buttonColors(containerColor = palette.accentBlue),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                ) {
                    if (isFixing) {
                        CircularProgressIndicator(
                            color = Color.White,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(currentFixStep ?: s.runningSmartFix)
                    } else {
                        Icon(Icons.Rounded.AutoFixHigh, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(s.oneTapSmartFix, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(Modifier.height(10.dp))

                OutlinedButton(
                    onClick = { showRestartConfirm = true },
                    enabled = shizukuReady && !isFixing,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Rounded.RestartAlt, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(s.refreshSystemUiBtn)
                }

                if (lastFixReport != null) {
                    Spacer(Modifier.height(12.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(palette.successGreen.copy(alpha = 0.12f))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "${s.smartFixSuccess} (+${lastFixReport.freedRamMb} MB)",
                            color = palette.successGreen,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        lastFixReport.stepsCompleted.forEach { step ->
                            Text(step, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }

        // 120Hz Animation Scale Tuner
        if (diagnostics != null) {
            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Speed, contentDescription = null, tint = palette.accentCyan)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(s.animationScaleTitle, style = MaterialTheme.typography.titleMedium)
                            Text(
                                s.animationScaleSubtitle,
                                style = MaterialTheme.typography.labelMedium,
                                color = palette.subtleText
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        val current = diagnostics.windowAnimationScale
                        FilterChip(
                            selected = current in 0.70f..0.80f,
                            onClick = { onSetAnimationScale(0.75f) },
                            enabled = shizukuReady,
                            label = { Text(s.presetIosSmooth) },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = current in 0.45f..0.55f,
                            onClick = { onSetAnimationScale(0.50f) },
                            enabled = shizukuReady,
                            label = { Text(s.presetUltraFast) },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = current in 0.95f..1.05f,
                            onClick = { onSetAnimationScale(1.0f) },
                            enabled = shizukuReady,
                            label = { Text(s.presetDefault) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Heavy Running Processes (Shizuku)
        if (diagnostics != null && diagnostics.heavyProcesses.isNotEmpty()) {
            item {
                Text(
                    text = s.heavyProcessesTitle,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
            items(diagnostics.heavyProcesses, key = { it.packageName }) { proc ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(proc.label, style = MaterialTheme.typography.titleMedium)
                            Text(
                                "${proc.memoryMb} MB RAM • ${proc.packageName}",
                                style = MaterialTheme.typography.labelSmall,
                                color = palette.subtleText
                            )
                        }
                        TextButton(
                            onClick = { onForceStopPackage(proc.packageName) },
                            enabled = shizukuReady
                        ) {
                            Icon(Icons.Rounded.StopCircle, contentDescription = null, tint = palette.dangerRed)
                            Spacer(Modifier.width(4.dp))
                            Text(s.forceStop, color = palette.dangerRed)
                        }
                    }
                }
            }
        }

        // Reversible XOS Bloatware / Heavy Overlay Manager
        item {
            Column(modifier = Modifier.padding(top = 6.dp)) {
                Text(
                    text = s.xosDebloaterTitle,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = s.xosDebloaterSubtitle,
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.subtleText
                )
            }
        }

        val xosList = diagnostics?.xosPackages.orEmpty()
        if (xosList.isEmpty()) {
            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = s.noXosPackagesFound,
                        style = MaterialTheme.typography.bodyMedium,
                        color = palette.subtleText
                    )
                }
            }
        } else {
            items(xosList, key = { it.spec.packageName }) { pkgStatus ->
                val spec = pkgStatus.spec
                val riskColor = if (spec.risk == PackageFreezeRisk.SAFE) palette.successGreen else palette.warningAmber
                val riskLabel = if (spec.risk == PackageFreezeRisk.SAFE) s.riskSafe else s.riskModerate

                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = if (isArabic) spec.titleAr else spec.titleEn,
                                    style = MaterialTheme.typography.titleMedium,
                                    modifier = Modifier.weight(1f, fill = false)
                                )
                                StatusPill(text = riskLabel, color = riskColor)
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = if (isArabic) spec.reasonAr else spec.reasonEn,
                                style = MaterialTheme.typography.bodyMedium,
                                color = palette.subtleText
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = spec.packageName,
                                style = MaterialTheme.typography.labelSmall,
                                color = palette.accentBlue
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Switch(
                                checked = pkgStatus.isEnabled,
                                enabled = shizukuReady,
                                onCheckedChange = { shouldEnable ->
                                    onToggleXosPackage(spec.packageName, !shouldEnable)
                                }
                            )
                            Text(
                                text = if (pkgStatus.isEnabled) s.active else s.frozen,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (pkgStatus.isEnabled) palette.successGreen else palette.warningAmber
                            )
                        }
                    }
                }
            }
        }
    }

    if (showShizukuGuide) {
        ShizukuSetupDialog(
            isInstalled = isShizukuInstalled,
            onDismiss = { showShizukuGuide = false },
            onOpenShizuku = onOpenShizukuApp,
            onOpenDevOptions = onOpenDevOptions
        )
    }

    if (showRestartConfirm) {
        AlertDialog(
            onDismissRequest = { showRestartConfirm = false },
            title = { Text(s.refreshSystemUiConfirmTitle) },
            text = { Text(s.refreshSystemUiConfirmBody) },
            confirmButton = {
                Button(
                    onClick = {
                        showRestartConfirm = false
                        onRestartSystemUi()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = palette.warningAmber)
                ) {
                    Text(s.confirm)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRestartConfirm = false }) {
                    Text(s.cancel)
                }
            }
        )
    }
}
